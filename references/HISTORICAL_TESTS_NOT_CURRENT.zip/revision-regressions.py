"""RC2 actual Senpa parser / Ryuten objects and native React picker.
Remote network/account/image responses and GPU submission are controlled fixtures, not a live certification.
"""
import asyncio,importlib.util,json,pathlib,shutil,base64
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('smoke',ROOT/'tests/browser-smoke.py');smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
async def run():
 results=[];errors=[];map_requests=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=chromium_path(),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1440,'height':900})
  page.set_default_timeout(6000)
  page.on('pageerror',lambda e:errors.append(str(e)))
  async def route(rt):
   u=rt.request.url
   if u.startswith('https://api.senpa.io/tracker'):
    await rt.fulfill(body=(ROOT/'references/tracker.json').read_text(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
   elif u=='https://i.imgur.com/aKvo1jQ.png' or '/fixture-' in u:
    map_requests.append(u);await rt.fulfill(body=PNG,content_type='image/png',headers={'Access-Control-Allow-Origin':'*'})
   else:await rt.abort()
  await page.route('**/*',route);await page.set_content('<html><body></body></html>');await page.evaluate('('+smoke.HOOK+')()')
  await page.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text());await page.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
  if not await page.evaluate('SENPA_PORT.ready'):raise RuntimeError(await page.evaluate('SENPA_PORT.error'))
  await page.evaluate((ROOT/'tests/browser-fixtures.js').read_text());await page.evaluate('FIXTURE.connect()');
  frame=await(await page.locator('#ryuten-senpa-frame').element_handle()).content_frame()
  async def check(name,code):
   try:
    detail=await page.evaluate('async()=>{const {h,port,rp,r,assert,Writer,world,advance,makeCell,mergedModel,sent}=FIXTURE;'+code+'}')
    results.append({'case':name,'pass':True,'detail':detail});print('PASS',name,detail,flush=True)
   except Exception as e:results.append({'case':name,'pass':False,'error':str(e)});print('FAIL',name,str(e),flush=True)
  await check('Internal grouping id and visible clan tag remain separate',"""
    new Writer(10).u8(0).u8(2).u16(41).u8(10).s16('team-opaque-a').s16('OWL').u16(42).u8(10).s16('team-opaque-a').s16('FRIEND').u8(0).send();
    world([{id:10,x:7400,y:7800,radius:150,parent:100},{id:11,x:7900,y:8200,radius:110,parent:101},{id:12,x:8600,y:8000,radius:190,parent:102,r:20,g:200,b:60}]);advance();
    assert(rp.world.clients.get(41)._9067==='OWL','Clan tag not used');
    assert(rp.world.clients.get(41)._senpaTeamId==='team-opaque-a','Grouping id lost');
    assert(![...rp.world.clients.values()].some(c=>c._9067.startsWith('team-')),'Internal ID leaked');
    return {label:rp.world.clients.get(41)._9067,groupRetained:true};
  """)
  await check('Client without a clan never displays a fabricated team label',"""
    new Writer(10).u8(0).u8(1).u16(42).u8(8).s16('').u8(0).send();advance();
    assert(rp.world.clients.get(42)._9067==='','Generated display tag');return {display:''};
  """)
  await check('Actual orb compositor uses cell RGB rather than black parent RGB',"""
    const cell=h.world.cells.get(12);const owner=h.world.playersList.get(102);owner.r=owner.g=owner.b=0;
    cell.color='#14c83c';r.Q.ORB_COLORING._7531('default');advance();
    const view=rp.world.cells.get(12).view,stage=new r.c.W20();r.n_._6212();r.n_._7703(view,stage);
    assert(view._6728._1026===0x14c83c,'Cell color overwritten');assert(stage.children[0].tint===0x14c83c,'Actual sprite still black');
    return {cellColor:cell.color,spriteTint:stage.children[0].tint};
  """)
  await check('Real server player-skin update feeds the Pixi skin cache',"""
    new Writer(11).u8(0).u8(1).u16(102).u8(2).s8('https://api.senpa.io/u/fixture-friend.png').u8(0).send();
    port.setSetting('cellSkin',true);port.setSetting('teammateCellSkin',true);port.setSetting('enemyCellSkin',false);advance();
    assert(rp.world.players.get(102)._3661.includes('fixture-friend.png'),'Same-team skin omitted because clan is empty');
    new Writer(10).u8(0).u8(1).u16(42).u8(2).s16('team-other').u8(0).send();advance();
    assert(rp.world.players.get(102)._3661==='','Enemy incorrectly treated as teammate');
    port.setSetting('enemyCellSkin',true);advance();assert(rp.world.players.get(102)._3661.includes('fixture-friend.png'),'Enemy preference not respected');
    port.setSetting('cellSkin',false);advance();assert([...rp.world.players.values()].every(p=>!p._3661),'Master skins OFF did not win');
    return {serverPacket:true,scopes:true,master:true};
  """)
  await check('Single shared names / mass / skins controls drive own and enemy visibility',"""
    const visible=Object.entries(r.Q).filter(([k,v])=>!v._portHidden);
    for(const name of ['Show names','Show mass','Show skins'])assert(visible.filter(([k,v])=>v._8192===name).length===1,'Duplicate '+name);
    r.Q.SHOW_ENEMY_USERNAME._7531(false);r.Q.SHOW_ENEMY_ENERGY._7531(false);r.Q.SHOW_CUSTOM_SKINS._7531(false);
    assert(!h.settings.cellNick&&!h.settings.cellMass&&!h.settings.cellSkin,'UI rows not canonical');
    assert(!r.Q.SHOW_OWN_USERNAME._5997()&&!r.Q.SHOW_OWN_ENERGY._5997()&&!r.Q.SHOW_OWN_CUSTOM_SKINS._5997(),'Hidden aliases disagree');
    port.setSetting('cellNick',true);port.setSetting('cellMass',true);port.setSetting('cellSkin',true);
    assert(r.Q.SHOW_ENEMY_USERNAME._5997()&&r.Q.SHOW_OWN_USERNAME._5997(),'Native update not propagated');
    return {visibleRows:visible.length,canonicalMasters:3};
  """)
  await check('Local captured loading artwork is the default map, borders remain server-owned',"""
    assert(r.Q.WORLD_BACKGROUND_IMAGE._5997(),'Map disabled by native default');
    assert(r.Q.BACKGROUND_IMAGE_URL._5997().startsWith('data:image/'),'Default map fetched remotely');
    for(let i=0;i<100&&rp.mapState.status==='loading';i++)await new Promise(resolve=>setTimeout(resolve,50));
    assert(rp.mapState.status==='ready','Fixture map did not load: '+JSON.stringify(rp.mapState));
    assert(r.It._5683.uTexture!==r.c.xEZ.WHITE.baseTexture,'Map texture not bound');
    h.border.update(0,0,20000,20000);advance();assert(r.ne._5142===20000,'Border not server supplied');
    h.border.update(0,0,16000,16000);advance();return {nativeShader:true,textureBound:true,serverBorders:true};
  """)
  await check('Map failure keeps previous texture and exposes retry state',"""
    const texture=r.It._5683.uTexture;r.Q.BACKGROUND_IMAGE_URL._7531('https://i.imgur.com/not-available-test.png');advance();
    for(let i=0;i<100&&rp.mapState.status==='loading';i++)await new Promise(resolve=>setTimeout(resolve,50));
    assert(rp.mapState.status==='error','No visible failure status');assert(r.It._5683.uTexture===texture,'Lost good map on failure');
    rp.restoreRyutenMap();advance();for(let i=0;i<100&&rp.mapState.status==='loading';i++)await new Promise(resolve=>setTimeout(resolve,50));assert(rp.mapState.status==='ready','Restore failed');return {lastGood:true,restored:true};
  """)
  await check('Native Senpa bar is 0..500 step5 and independent of Ryuten range',"""
    port.setSetting('cellAnimation',325);r.Q.ELEMENT_ANIMATION_SOFTENING._7531(180);
    r.Q.PRESENTATION_STYLE._7531('Ryuten');assert(h.settings.cellAnimation===325,'Senpa delay overwritten');
    const bar=port.frame.contentDocument.querySelector('[data-senpa-animation]');assert(bar.min==='80'&&bar.max==='300'&&bar.step==='10','Ryuten limits wrong');
    r.Q.PRESENTATION_STYLE._7531('Senpa');assert(bar.min==='0'&&bar.max==='500'&&bar.step==='5'&&bar.value==='325','Senpa bar not restored');
    assert(r.Q.ELEMENT_ANIMATION_SOFTENING._5997()===180,'Ryuten delay lost');return {senpa:325,ryuten:180};
  """)
  try:
   await frame.evaluate('RYUTEN_PORT.showMenu()');await page.wait_for_timeout(70)
   selector=frame.locator('select[aria-label="Animation / gameplay style"]')
   bar=frame.locator('[data-senpa-animation]')
   await selector.select_option('Senpa');await bar.focus();await page.keyboard.press('Home')
   assert await page.evaluate('SENPA_HOST.settings.cellAnimation')==0
   await page.keyboard.press('End');assert await page.evaluate('SENPA_HOST.settings.cellAnimation')==500
   await selector.select_option('Ryuten');await bar.focus();await page.keyboard.press('Home')
   assert await frame.evaluate('RYUTEN_PORT.reference.Q.ELEMENT_ANIMATION_SOFTENING._5997()')==80
   await page.keyboard.press('End');assert await frame.evaluate('RYUTEN_PORT.reference.Q.ELEMENT_ANIMATION_SOFTENING._5997()')==300
   assert await page.evaluate('SENPA_HOST.settings.cellAnimation')==500
   await selector.select_option('Senpa');assert await bar.input_value()=='500'
   await page.evaluate('SENPA_PORT.setSetting("cellAnimation",325);SENPA_PORT.child.reference.Q.ELEMENT_ANIMATION_SOFTENING._7531(180)')
   results.append({'case':'Real profile selector and keyboard slider input preserve native zero and both range endpoints','pass':True})
  except Exception as e:
   results.append({'case':'Real profile selector and keyboard slider input','pass':False,'error':str(e)})
  await check('Ryuten position / radius and interrupted retarget match the original J_ sampler',"""
    const oldFrame=port.onFrame;port.onFrame=null;r.Q.PRESENTATION_STYLE._7531('Ryuten');
    const c=h.world.cells.get(10),view=rp.world.cells.get(10).view;
    const cases=[];const oldTime=r.n._4541;
    for(const ms of [80,160,180,300]){
      r.Q.ELEMENT_ANIMATION_SOFTENING._7531(ms);c.x=c.startX=c.endX=100;c.y=c.startY=c.endY=200;c.radius=c.startRadius=c.endRadius=40;c.animating=false;
      rp.motion.records.delete(c);rp.motion.create(c,1000);r.n._4541=1000;
      const original=new r.J_(999999,100,200,40,r.A._2479);
      c.update(340,500,100,1000);original._4659(340,500,100);
      for(const elapsed of [0,40,70]){rp.motion.frameNow=1000+elapsed;r.n._4541=1000+elapsed;original._5792();view._5792();
        assert(Math.abs(view._7847-rp.world.offset-original._7847)<1e-7,'Position differs from source');
        assert(Math.abs(view._1904-original._1904)<1e-7,'Radius differs from source');}
      const displayedBeforeRetarget=rp.motion.sample(c,1070);c.update(600,650,140,1070);r.n._4541=1070;original._4659(600,650,140);
      const retargeted=rp.motion.records.get(c);assert(Math.abs(retargeted.fromX-displayedBeforeRetarget.x)<1e-7,'Retarget did not start from displayed position');assert(Math.abs(retargeted.fromY-displayedBeforeRetarget.y)<1e-7,'Retarget Y did not start from displayed position');assert(Math.abs(retargeted.fromR-displayedBeforeRetarget.r)<1e-7,'Retarget radius did not start from displayed position');
      rp.motion.frameNow=1110;r.n._4541=1110;original._5792();view._5792();
      assert(Math.abs(view._7847-rp.world.offset-original._7847)<1e-7,'Retarget differs');cases.push({ms,x:original._7847});
    }
     r.n._4541=oldTime;c.animating=false;c.updateTime=performance.now();r.Q.PRESENTATION_STYLE._7531('Senpa');port.onFrame=oldFrame;advance();return cases;
   """)
  await check('Ryuten cell-source switches preserve the displayed pose and each source clock',"""
    const oldStyle=rp.motion.style,oldDelay=rp.motion.delay,oldBuild=port.multibox.worldView.build,oldActive=h.player.activeTab;
    const c=h.world.cells.get(10),entry=rp.world.cells.get(10),saved={startX:c.startX,x:c.x,endX:c.endX,startY:c.startY,y:c.y,endY:c.endY,startRadius:c.startRadius,radius:c.radius,endRadius:c.endRadius,updateTime:c.updateTime,animating:c.animating,radiusAnimating:c.radiusAnimating,dt:c.dt};
    const base=[...h.world.cells.values()].filter(cell=>cell!==c),model=(source,active)=>mergedModel([...base,source],active);
    const replacement=makeCell(c.id,1000,2000,65,c.parentPlayerID,c.type);replacement.startX=replacement.x=1000;replacement.endX=1100;replacement.startY=replacement.y=2000;replacement.endY=2000;replacement.startRadius=replacement.radius=65;replacement.endRadius=75;replacement.updateTime=5000;replacement.animating=true;replacement.radiusAnimating=true;
    try{
      r.Q.ELEMENT_ANIMATION_SOFTENING._7531(200);r.Q.PRESENTATION_STYLE._7531('Ryuten');rp.motion.records.delete(c);
      Object.assign(c,{startX:100,x:100,endX:100,startY:200,y:200,endY:200,startRadius:40,radius:40,endRadius:40,updateTime:900,animating:false,radiusAnimating:false,dt:1});
      port.multibox.worldView.build=()=>model(c,0);rp.motion.frameNow=1000;c.update(300,200,40,1000);rp.world.sync();
      rp.motion.frameNow=1100;entry.view._5792();const displayed=entry.view._7847-rp.world.offset;assert(Math.abs(displayed-200)<1e-7,'Initial Ryuten pose was not sampled');
      port.multibox.worldView.build=()=>model(replacement,1);rp.world.sync();const rebound=entry.view._7847-rp.world.offset,record=rp.motion.records.get(replacement);assert(Math.abs(rebound-displayed)<1e-7,'Source switch jumped from displayed pose');assert(record&&Math.abs(record.fromX-displayed)<1e-7,'Replacement record mixed stale source state');assert(record.at===1100,'Replacement used the wrong cell animation clock');
      rp.motion.frameNow=1200;entry.view._5792();assert(Math.abs(entry.view._7847-rp.world.offset-650)<1e-7,'Replacement target did not continue from displayed pose');
      h.player.activeTab=0;rp.world.sync();port.request('switch',1);rp.world.sync();assert(h.player.activeTab===1,'Native player tab switch was not preserved');const afterTabSwitch=entry.view._7847-rp.world.offset;assert(Math.abs(afterTabSwitch-650)<1e-7,'Native tab switch changed Ryuten cell pose');return {displayed,rebound,afterTabSwitch,clock:record.at,target:record.toX};
    }finally{
      port.multibox.worldView.build=oldBuild;Object.assign(c,saved);rp.motion.records.delete(replacement);r.Q.ELEMENT_ANIMATION_SOFTENING._7531(oldDelay);if(oldStyle!==rp.motion.style)r.Q.PRESENTATION_STYLE._7531(oldStyle);h.player.activeTab=oldActive;rp.motion.frameNow=performance.now();rp.world.sync();
    }
  """)
  await check('All cell styles preserve native Senpa camera and wheel ownership',"""
    for(const style of ['Senpa','Ryuten','XPLUS']){
      const before={x:h.camera.x,y:h.camera.y,z:h.camera.zoom,t:h.camera.targetZoom};
      r.Q.PRESENTATION_STYLE._7531(style);
      assert(h.camera.x===before.x&&h.camera.y===before.y&&h.camera.zoom===before.z&&h.camera.targetZoom===before.t,'Style reset camera state');
      advance();const scale=r.X_._3473/port.frame.contentWindow.innerWidth;
      rp.world.camera();assert(Math.abs(r.z_._3852._7847-rp.world.offset-h.camera.x)<1e-7,'Camera copied incorrectly');
      assert(Math.abs(r.z_._4336-h.camera.zoom*scale)<1e-7,'Zoom copied incorrectly');
      h.camera.targetZoom=.3;const wheel=h.settings.zoomSpeed;rp.motion.wheel({deltaY:1});
      assert(Math.abs(h.camera.targetZoom-.3*wheel)<1e-7,'Wheel not native Senpa');
    }
    r.Q.PRESENTATION_STYLE._7531('Senpa');return {profiles:3,cameraOwner:'Senpa',singleIntegrator:true};
  """)
  # Real DOM keyboard / navigation, including focused inputs.
  for name,action in [
   ('Escape returns from Settings to main menu', 'settings'),
   ('Escape returns from Inventory to main menu', 'inventory'),
   ('Escape dismisses import/export before the settings screen', 'import')]:
   try:
    await frame.evaluate('RYUTEN_PORT.showMenu()');await page.wait_for_timeout(80)
    await frame.locator('#mame-trb-'+('settings' if action=='import' else action)+'-btn').click();await page.wait_for_timeout(80)
    if action=='import':
     await frame.evaluate('RYUTEN_PORT.reference.yt._5990()');await page.wait_for_timeout(40)
    # Body focus places key in iframe rather than parent.
    await frame.locator('body').click(position={'x':700,'y':80});await page.keyboard.press('Escape');await page.wait_for_timeout(100)
    state=await frame.evaluate('()=>({stack:RYUTEN_PORT.reference.rs._9222.map(m=>m._9782),modal:getComputedStyle(document.getElementById("import-export-menu")).display})')
    assert state['stack']==(['main-menu','settings-menu'] if action=='import' else ['main-menu']),state
    if action=='import':assert state['modal']=='none'
    results.append({'case':name,'pass':True,'detail':state});print('PASS',name,state,flush=True)
   except Exception as e:results.append({'case':name,'pass':False,'error':str(e)});print('FAIL',name,str(e),flush=True)
  try:
   await frame.evaluate('RYUTEN_PORT.showMenu()');await page.wait_for_timeout(60)
   await frame.locator('#mame-trb-settings-btn').click();await page.wait_for_timeout(60)
   await frame.locator('.sm-category-selector').filter(has_text='Theme').click();await page.wait_for_timeout(60)
   inp=frame.locator('#settings-menu input[type=text]:visible').first
   if await inp.count():await inp.focus()
   else:await frame.locator('body').click(position={'x':700,'y':80})
   await page.keyboard.press('Escape');await page.wait_for_timeout(100)
   assert await frame.evaluate('RYUTEN_PORT.reference.rs._9222.length')==1
   results.append({'case':'Escape works with a focused settings input','pass':True})
  except Exception as e:results.append({'case':'Escape with focused settings input','pass':False,'error':str(e)})
  await check('Senpa native account skin routes update both previews without URL writes',"""
    h.store.account={id:900,real_name:'Fixture account',experience:100000,coins:50,skin_profiles:[{skin_id_1:11,skin_id_2:12}],skin_routes:{11:'fixture-own-1.png',12:'fixture-own-2.png'},favorites:[]};
    rp.syncAccountSkins();
    assert(r.Be._4564[0]==='https://api.senpa.io/u/fixture-own-1.png','Primary preview wrong');
    assert(r.Be._4564[1]==='https://api.senpa.io/u/fixture-own-2.png','Secondary preview wrong');
    assert(r.is._2736[2]===r.Be._4564[0],'Menu preview differs');
    return {source:'native mS route resolver',twoSlots:true};
  """)
  # The original React gallery and permissions are exercised using fixture API functions, not reimplemented UI.
  await check('Prepare controlled responses for original authenticated gallery',"""
    await new Promise(resolve=>setTimeout(resolve,200));
    port.testAccount={id:900,real_name:'Fixture account',experience:100000,coins:50,skin_profiles:[{skin_id_1:11,skin_id_2:12}],skin_routes:{11:'fixture-own-1.png',12:'fixture-own-2.png'},favorites:[]};
    h.account.request=async path=>path==='/account/'?JSON.parse(JSON.stringify(port.testAccount)):path.startsWith('/skins/')?{results:[{id:21,skin_name:'Fixture selectable skin',skin_route:'fixture-selected.png',requirement_type:0,requirement_data:'0'}]}:{};
    h.account.requestJson=async(path,payload)=>{port.lastSkinSave={path,payload};return {success:true};};
    const fixtureJWT='e30.'+btoa(JSON.stringify({exp:Math.floor(Date.now()/1000)+3600})).replace(/=+$/,'')+'.Zml4dHVyZQ';
    h.account.setToken(fixtureJWT);h.store.account=port.testAccount;await new Promise(resolve=>setTimeout(resolve,150));
    assert(document.getElementById('skin-preview-1'),'Original skin button missing');return {originalReactMounted:true};
  """)
  try:
   # Advanced native fallback remains regression-tested; normal buttons now use
   # the in-Ryuten account panel covered by account-browser-regressions.py.
   await frame.evaluate('RYUTEN_PORT.showMenu()');await page.evaluate('SENPA_PORT.openLegacySkinPicker(0)');
   await page.locator('.skins-modal').wait_for(state='visible',timeout=6000)
   button=page.locator('.skins-modal .grid-item button').filter(has_text='Equip').first;await button.wait_for(state='visible',timeout=6000);await button.click()
   await page.wait_for_timeout(300)
   result=await page.evaluate('()=>({mode:SENPA_PORT.mode,skin:SENPA_PORT.child.reference.Be._4564[0],save:SENPA_PORT.lastSkinSave,source:SENPA_HOST.store.account.skin_profiles[0]})')
   assert result['skin']=='https://api.senpa.io/u/fixture-selected.png',result
   assert result['save']['path']=='/account/save-profile',result
   assert result['mode']=='ryuten',result
   results.append({'case':'Skin 1 button opens original gallery; Equip persists via native route and returns','pass':True,'detail':result});print('PASS','Original skin gallery Equip',result,flush=True)
  except Exception as e:
   detail=await page.evaluate('()=>({mode:SENPA_PORT.mode,context:SENPA_PORT.nativeContext,account:SENPA_HOST.store.account,tokenPresent:!!SENPA_HOST.store.authToken,skinModal:!!document.querySelector(".skins-modal"),warning:document.querySelector(".swal2-container")?.textContent})')
   results.append({'case':'Original skin gallery Equip','pass':False,'error':str(e),'detail':detail});print('FAIL','Original skin gallery',str(e),detail,flush=True)
  try:
   await frame.evaluate('RYUTEN_PORT.showMenu()');await page.wait_for_timeout(80)
   await page.evaluate('SENPA_PORT.openLegacySkinPicker(1)');await page.locator('.skins-modal').wait_for(state='visible')
   await page.locator('.skins-modal .grid-item button').filter(has_text='Equip').first.click();await page.wait_for_timeout(300)
   result=await page.evaluate('()=>({mode:SENPA_PORT.mode,skin:SENPA_PORT.child.reference.Be._4564[1],save:SENPA_PORT.lastSkinSave})')
   assert result['skin']=='https://api.senpa.io/u/fixture-selected.png',result
   assert result['save']['payload']['profile']['route2']=='fixture-selected.png',result
   assert result['mode']=='ryuten',result
   results.append({'case':'Skin 2 selects the actual second Senpa account slot','pass':True,'detail':result})
   await page.evaluate('SENPA_PORT.openLegacySkinPicker(1)');await page.locator('.skins-modal').wait_for(state='visible')
   await page.keyboard.press('Escape');await page.wait_for_timeout(300)
   assert await page.evaluate('SENPA_PORT.mode')=='ryuten',await page.evaluate('()=>({mode:SENPA_PORT.mode,context:SENPA_PORT.nativeContext,focus:document.activeElement?.tagName,modal:!!document.querySelector(".skins-modal")})')
   results.append({'case':'Escape exits the original native skin gallery back to Ryuten','pass':True})
  except Exception as e:
   results.append({'case':'Second native skin picker and Escape','pass':False,'error':str(e)})
  await check('Both animation values and canonical settings export without account tokens',"""
    let payload;const old=rp.download;rp.download=(name,text)=>payload=JSON.parse(text);rp.exportSettings();rp.download=old;
    assert(payload.version===2,'Old ambiguous export');assert(payload.senpa.cellAnimation===h.settings.cellAnimation,'Senpa delay missing');
    assert(payload.ryuten.ELEMENT_ANIMATION_SOFTENING===r.Q.ELEMENT_ANIMATION_SOFTENING._5997(),'Ryuten delay missing');
    assert(!JSON.stringify(payload).includes('LOCAL_TEST_TOKEN'),'Credentials exported');assert(!payload.cosmetics.skins,'Account skins exported as arbitrary override');
    const oldMs=h.settings.cellAnimation;await rp.importSettings({size:20000,text:async()=>JSON.stringify(payload)});assert(h.settings.cellAnimation===oldMs,'Roundtrip changed delay');return {version:2,noCredentials:true};
  """)
  await check('Native overlay and duplicate metric writers remain hidden while port is active',"""
    port.showRyuten();advance();const nativeMap=document.querySelector('.minimap-root');
    if(nativeMap)assert(getComputedStyle(nativeMap).visibility==='hidden','Native minimap leaked');
    assert(port.frame.contentWindow.getComputedStyle(port.frame.contentDocument.getElementById('fps')).display==='none','Duplicate metrics visible');
    return {singleMinimap:true,singleMetrics:true};
  """)
  await check('No unhandled production rendering errors',"""
    const errors=port.logs.filter(x=>x.event==='presentation-error');assert(errors.length===0,JSON.stringify(errors));return {frames:rp.world.frameCount};
  """)
  await frame.evaluate('RYUTEN_PORT.showMenu()');await page.wait_for_timeout(80);await page.screenshot(path=str(ROOT/'verification/rc2-menu.png'))
  try:
   await frame.locator('#mame-trb-settings-btn').click();await page.wait_for_timeout(120);await page.screenshot(path=str(ROOT/'verification/rc2-merged-settings.png'))
  except:pass
  try:
   await page.evaluate('SENPA_PORT.setSetting("cellAnimation",315);SENPA_PORT.setSetting("cellNick",false);SENPA_PORT.child.reference.Q.ELEMENT_ANIMATION_SOFTENING._7531(270);SENPA_PORT.child.reference.Q.PRESENTATION_STYLE._7531("Ryuten")')
   seed=await page.evaluate('()=>({host:localStorage.getItem("Senpaio:settings"),child:SENPA_PORT.frame.contentWindow.localStorage.getItem("ryuten.senpa.v1.preferences")})')
   reloaded=await browser.new_page(viewport={'width':1440,'height':900});await reloaded.route('**/*',route)
   reloaded.on('pageerror',lambda e:errors.append(str(e)))
   await reloaded.set_content('<html><body></body></html>');await reloaded.evaluate('('+smoke.HOOK+')()')
   await reloaded.evaluate("""seed=>{
    localStorage.setItem('Senpaio:settings',seed.host);
    const desc=Object.getOwnPropertyDescriptor(window,'SENPA_PORT');
    Object.defineProperty(window,'SENPA_PORT',{configurable:true,get:desc.get,set:v=>{
      desc.set(v);const previous=v.test.prepareChild;
      v.test.prepareChild=win=>{previous(win);win.localStorage.setItem('ryuten.senpa.v1.preferences',seed.child);};
    }});
   }""",seed)
   await reloaded.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text());await reloaded.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
   state=await reloaded.evaluate('()=>({ready:SENPA_PORT.ready,style:SENPA_PORT.child.motion.style,senpa:SENPA_HOST.settings.cellAnimation,ryuten:SENPA_PORT.child.motion.delay,names:SENPA_PORT.child.reference.Q.SHOW_ENEMY_USERNAME._5997(),map:SENPA_HOST.settings.backgroundImageURL})')
   assert state['map'].startswith('data:image/'), 'Local map was not restored'
   state['map']='embedded local artwork'
   assert state=={'ready':True,'style':'Ryuten','senpa':315,'ryuten':270,'names':False,'map':'embedded local artwork'},state
   results.append({'case':'Full userscript restart restores independent profiles, canonical visibility and map preference','pass':True,'detail':state})
   await reloaded.close()
  except Exception as e:
   results.append({'case':'Full userscript restart preference migration','pass':False,'error':str(e)})
  output={'release':'1.2.0-rc.1','network':'fixture responses','gpu':'submission substituted','mapPixels':'1px test image, NOT reference art',
    'cases':results,'pageErrors':errors,'imageRequests':map_requests,'pass':all(x['pass']for x in results) and not errors}
  (ROOT/'verification/rc2-regressions.json').write_text(json.dumps(output,indent=2));await browser.close()
  return output['pass']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(run()) else 1)
