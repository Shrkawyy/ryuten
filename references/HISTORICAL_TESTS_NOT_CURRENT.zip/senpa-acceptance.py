"""1.2 acceptance: actual Senpa parsers/Pixi objects, simulated network/GPU only."""
import asyncio,importlib.util,json,pathlib,shutil,hashlib
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
def module(name,file):
 s=importlib.util.spec_from_file_location(name,ROOT/'tests'/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
smoke=module('smoke','browser-smoke.py');wb=module('wb','windbine-multibox-regressions.py')
source=(ROOT/'src/senpa/client.js').read_text();start=source.index('V=new class{')+len('V=new ');end=source.index('},he=1024',start)+1
CAMERA=source[start:end]
async def main():
 results=[];errors=[];requests=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=chromium_path(),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
  async def route(q):
   u=q.request.url;requests.append({'url':u,'type':q.request.resource_type})
   if u=='https://senpa.io/web/':await q.fulfill(body='<!doctype html><html><head></head><body></body></html>',content_type='text/html')
   elif u.startswith('https://api.senpa.io/tracker'):await q.fulfill(body=(ROOT/'references/tracker.json').read_text(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
   else:await q.abort()
  await page.route('**/*',route);await page.set_content('<!doctype html><html><head></head><body></body></html>');await page.evaluate('('+smoke.HOOK+')()')
  await page.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text());await page.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
  if not await page.evaluate('SENPA_PORT.ready'):raise RuntimeError(await page.evaluate('SENPA_PORT.error'))
  async def check(name,body):
   try:
    value=await page.evaluate('async()=>{const p=SENPA_PORT,h=SENPA_HOST,rp=p.child,r=rp.reference,m=p.multibox,T=window.WBTEST;const assert=(x,msg)=>{if(!x)throw Error(msg);};'+body+'}')
    results.append({'case':name,'pass':True,'detail':value});print('PASS',name,value,flush=True)
   except Exception as e:results.append({'case':name,'pass':False,'error':str(e)});print('FAIL',name,str(e)[:1800],flush=True)
  await check('Boot does not silently connect and FFA is enabled by default',"""
    assert(!h.network.connected&&!h.network.ws,'Native UI connected behind port selection');
    assert(m.ffaEnabled===true&&r.Q.FFA_MULTIBOX_ENABLED._5997()===true,'FFA not default on');
    assert(r.Q.MULTIBOX_RING._5997()===true,'Active ring not default on');
    assert(r.Q.BACKGROUND_IMAGE_URL._5997().startsWith('data:image/'),'Default background not embedded');
    assert(rp.asset('assets/missing-check.png').startsWith('data:'),'Missing Ryuten artwork falls back remotely');
    assert(!document.querySelector('script[src*=cloudflare]'),'Verification SDK loaded without challenge');
    return {version:rp.build.version,connected:false,ffa:true,ring:true,fonts:rp.status.fonts};
  """)
  print('SETUP',await page.evaluate(wb.PREPARE),flush=True)
  await check('WindBine four-slot secondary handshake and native parser assignment',"""
    m.setWindBineEnabled(true);m.setNearSpawn(false);m.request('switch',2);
    for(let i=0;i<160&&!m.aux;i++)await new Promise(q=>setTimeout(q,25));assert(m.aux,'Aux did not initialize');
    const a=m.aux.host,s=m.aux.frame.contentWindow.testSocket;assert(s,'Aux transport missing');s.open();T.assign(a,42,[200,201]);
    T.info(a,[[200,42,'Secondary'],[201,42,'Secondary']]);T.world(a,[{id:3,parent:200,x:7600,y:7100,radius:90},{id:4,parent:201,x:7800,y:7100,radius:110}]);
    m.tick(performance.now());T.frame();assert(m.multi&&m.tabCount()===4,'Four slots unavailable');
    assert(rp.world.model.myPlayerIDs.join(',')==='100,101,200,201','Wrong logical IDs');rp.hideMenu();
    return {slots:m.slots(),ids:rp.world.model.myPlayerIDs};
  """)
  await page.evaluate('(source)=>{window.SENPA_CAMERA_ORACLE=source;}',CAMERA)
  await check('3,600 frame camera comparison against extracted native Senpa class',"""
    p.onFrame=null;const descriptors={enabled:false},b={x:0,y:0,isAlive:true};
    const oracle=Function('E','B','M','T','ae','document','self','de','fe','pe','me','return new '+SENPA_CAMERA_ORACLE)(
      h.settings,b,descriptors,h.border,{isOpen:true},{addEventListener(){}},window,.25,.04,1,8);
    let maxError=0;const oldAuto=h.settings.autoZoom;
    for(const style of ['Senpa','Ryuten','XPLUS']){
      r.Q.PRESENTATION_STYLE._7531(style);h.camera.x=oracle.x=6000;h.camera.y=oracle.y=6100;
      h.camera.zoom=oracle.zoom=.2;h.camera.targetZoom=oracle.targetZoom=.25;
      for(let i=0;i<1200;i++){
        if(i%29===0)m.select((m.active+1)%4);
        const alive=[];for(const host of [h,m.aux.host])for(const set of host.world.myCells)for(const c of set.values())if(!c.removed)alive.push(c);
        for(let j=0;j<alive.length;j++){alive[j].x=6500+j*350+Math.sin(i*.025+j)*220;alive[j].y=6800+j*120+Math.cos(i*.018)*160;}
        b.x=alive.reduce((sum,c)=>sum+c.x,0)/alive.length;b.y=alive.reduce((sum,c)=>sum+c.y,0)/alive.length;
        h.settings.autoZoom=i%120<60;oracle.autoZoom=Math.pow(Math.min(64/alive.reduce((sum,c)=>sum+c.radius,0),1),.4)*Math.max(innerWidth/1920,innerHeight/1080);
        if(i%77===0){const e={deltaY:i%154===0?1:-1};rp.motion.wheel(e);oracle.onMouseWheel(e);}
        oracle.update();h.camera.update();
        maxError=Math.max(maxError,Math.abs(oracle.x-h.camera.x),Math.abs(oracle.y-h.camera.y),Math.abs(oracle.zoom-h.camera.zoom));
        assert(maxError<1e-7,'Camera drift '+style+' '+i+' error '+maxError);
      }
    }
    h.settings.autoZoom=oldAuto;return {profiles:3,frames:3600,maxError,source:'src/senpa/client.js V class'};
  """)
  await check('Primary and secondary chat routing is nonrecursive and exactly once',"""
    for(const slot of [0,1,2,3,0]){m.select(slot);T.primarySocket.sent.length=0;m.aux.frame.contentWindow.testSocket.sent.length=0;
      h.packets.chat(1,'fixture');const counts=[T.primarySocket.sent.length,m.aux.frame.contentWindow.testSocket.sent.length];
      assert(counts[slot<2?0:1]===1&&counts[slot<2?1:0]===0,'Chat sent to wrong host or recursively '+counts);
    }return {slots:4,primaryRecursive:false};
  """)
  await check('Chat focus suppresses gameplay hotkeys and follows new messages',"""
    rp.hideMenu();rp.toggleChat();const input=p.frame.contentDocument.getElementById('senpa-chat-input');
    assert(h.menu.isChatFocused&&input===p.frame.contentDocument.activeElement,'Chat did not receive focus');
    const a=m.active,prev=T.primarySocket.sent.length+m.aux.frame.contentWindow.testSocket.sent.length;
    const e=new p.frame.contentWindow.KeyboardEvent('keydown',{key:'Tab',code:'Tab',bubbles:true});input.dispatchEvent(e);
    assert(m.active===a,'Typing in chat switched cells');assert(prev===T.primarySocket.sent.length+m.aux.frame.contentWindow.testSocket.sent.length,'Chat key emitted gameplay packet');
    for(let i=0;i<150;i++)rp.addChat({nick:'fixture',message:'new-message-'+i});await new Promise(q=>setTimeout(q,50));
    const chat=p.frame.contentDocument.getElementById('chbx-body-content');assert(chat.childElementCount===120,'Chat cap missing');
    assert(chat.scrollHeight-chat.clientHeight-chat.scrollTop<2,'New messages not scrolled into view');
    rp.toggleChat();return {boundedMessages:120,remainingScroll:chat.scrollHeight-chat.clientHeight-chat.scrollTop};
  """)
  await check('Native held feed moves across all four slots and keyup stops both sources',"""
    rp.hideMenu();r.Q.FEED_INTERVAL_MS._7531(0);h.settings.feedFollowsTab=true;m.select(0);h.actions.macroFeed(true);
    for(const slot of [1,2,3,0,3]){m.select(slot);const target=m.host(slot),other=target===h?m.aux.host:h;
      assert(target.actions.isMacroFeeding&&!other.actions.isMacroFeeding,'Inactive native stream persisted at '+slot);
      assert(target.actions.macroFeedTab===slot%2,'Wrong native feed slot '+target.actions.macroFeedTab);
    }
    h.actions.macroFeed(false);assert(!h.actions.isMacroFeeding&&!m.aux.host.actions.isMacroFeeding,'Keyup left feed active');
    return {transfers:5,bothStopped:true};
  """)
  await check('Custom feed preserves deadline and route on slots 2 and 3',"""
    rp.hideMenu();r.Q.FEED_INTERVAL_MS._7531(80);h.settings.feedFollowsTab=true;m.select(2);
    const s=m.aux.frame.contentWindow.testSocket;s.sent.length=0;h.actions.macroFeed(true);m.select(3);
    let feed=s.sent.filter(x=>x[0]===23);assert(feed.length===1&&feed[0][1]===0,'Switch injected pulse');
    await new Promise(q=>setTimeout(q,110));h.actions.macroFeed(false);feed=s.sent.filter(x=>x[0]===23);
    assert(feed.some(x=>x[1]===1&&x[2]===0),'Native slot one missed custom pulse');
    const count=feed.length;await new Promise(q=>setTimeout(q,100));assert(s.sent.filter(x=>x[0]===23).length===count,'Late inactive pulse');return {packets:feed};
  """)
  await check('Default/custom/multibox colors and active ring do not require shield',"""
    r.Me._2232('');r.Q.MULTIBOX_RING._7531(true);m.select(3);T.frame();
    const own=[...rp.world.cells.values()].find(e=>e.view._2182._3090===3)?.view;assert(own,'Fourth logical cell absent');
    r.Q.OWN_ORB_COLORING._7531('default');assert(rp.orbTint(own,0)===own._6728._1026,'Game tint lost');
    r.Q.CUSTOM_OWN_ORB_COLOR._7531(0x123456);r.Q.OWN_ORB_COLORING._7531('custom');assert(rp.orbTint(own,0)===0x123456,'Custom ignored');
    r.Q.OWN_ORB_COLORING._7531('multibox');assert(rp.orbTint(own,0)===r.Q.ACTIVE_PLAYER_UNIT_ACCENT_COLOR._5997(),'Active logical slot 3 tint lost');
    rp.cosmetics.begin(performance.now());let stage=new r.c.W20();rp.drawCosmetics(own,stage,1);
    assert(stage.children.some(s=>s.texture===rp.renderParity.ringTexture),'Ring requires shield');
    m.select(0);rp.world.sync();rp.cosmetics.begin(performance.now());stage=new r.c.W20();rp.drawCosmetics(own,stage,1);
    assert(!stage.children.some(s=>s.texture===rp.renderParity.ringTexture),'Inactive slot retains ring');
    r.Q.OWN_ORB_COLORING._7531('default');return {logicalSlot:3,modes:3,ringIndependent:true};
  """)
  await check('All profiles use native pellet geometry, alpha, and texture coverage',"""
    const source=new h.Cell(9000,7300,7100,20,2);h.world.cells.set(9000,source);
    const answers=[];for(const style of ['Senpa','Ryuten','XPLUS']){r.Q.PRESENTATION_STYLE._7531(style);T.frame();
      const view=rp.world.cells.get(9000).view,stage=new r.c.W20();r.Bt._6212();r.Bt._7703(view,stage);
      const sprite=stage.children[0];assert(Math.abs(sprite.width-40)<1e-7&&sprite.alpha===1,'Pellet radius/alpha differs');
      assert(sprite.texture===rp.renderParity.pelletTexture,'Not native 64px circle');answers.push({style,diameter:sprite.width,alpha:sprite.alpha});
    }return answers;
  """)
  await check('Line split aims first, splits once, restores and cancels on switch',"""
    rp.hideMenu();m.select(0);r.Q.FEED_INTERVAL_MS._7531(0);h.input.mouse.x=1000;h.input.mouse.y=550;const s=T.primarySocket;
    s.sent.length=0;assert(rp.lineSplit.trigger({settleMs:20}),'Line macro did not start');
    await new Promise(q=>setTimeout(q,35));const split=s.sent.filter(x=>x[0]===22);assert(split.length===1&&split[0][1]===0&&split[0][2]===6,'Wrong split opcode/count');
    const idx=s.sent.findIndex(x=>x[0]===22);assert(idx>0&&s.sent[idx-1][0]!==22,'Aim not before split');
    await new Promise(q=>setTimeout(q,70));assert(!rp.lineSplit.snapshot().active,'Macro did not release');
    s.sent.length=0;assert(rp.lineSplit.trigger({settleMs:80}),'Second trigger failed');m.select(1);
    await new Promise(q=>setTimeout(q,120));assert(!s.sent.some(x=>x[0]===22),'Cancelled macro split inactive slot');
    return {wireCount:6,finite:true,cancelledOnSwitch:true};
  """)
  await check('FFA restoration: second native connection owns slot zero, default on',"""
    m.destroyAux();p.tracker.servers=[{id:'ffa',host:h.network.url,name:'FFA fixture',mode:'ffa',modeName:'Free for all',region:'EU'}];
    assert(m.ffaEnabled,'FFA default changed');T.assign(h,41,[100]);T.info(h,[[100,41,'P1']]);T.world(h,[{id:10,parent:100,x:7000,y:7000,radius:100}]);T.frame();
    assert(m.multi&&m.tabCount()===2,'FFA controller not active');m.request('switch',1);
    for(let i=0;i<160&&!m.aux;i++)await new Promise(q=>setTimeout(q,25));assert(m.aux,'FFA P2 did not initialize');
    const a=m.aux.host,s=m.aux.frame.contentWindow.testSocket;s.open();T.assign(a,42,[200]);T.info(a,[[200,42,'P2']]);
    T.world(a,[{id:20,parent:200,x:7200,y:7000,radius:100}]);m.tick(performance.now());T.frame();m.select(1);
    assert(m.active===1&&a.player.activeTab===0&&h.world.myPlayerIDs.length===1,'Invented native FFA slot one');
    rp.hideMenu();r.Q.FEED_INTERVAL_MS._7531(0);h.actions.macroFeed(true);assert(a.actions.isMacroFeeding&&!h.actions.isMacroFeeding,'FFA feed wrong engine');
    m.select(0);assert(h.actions.isMacroFeeding&&!a.actions.isMacroFeeding,'FFA old feed retained');h.actions.macroFeed(false);
    assert(rp.world.model.myCells.length===2,'FFA merged cells missing');return {nativeSlots:[h.world.myPlayerIDs.length,a.world.myPlayerIDs.length],logicalSlots:m.slots()};
  """)
  await check('Server selector reports connected endpoint even when tracker omits it',"""
    const url=h.network.url,ws=h.network.ws;p.selected='eu9.senpa.io:7777';p.tracker.servers=[{id:'new',host:p.selected,name:'Other',region:'EU',mode:'ffa'}];
    rp.renderServers();const select=p.frame.contentDocument.getElementById('senpa-server-select');assert(select.value===url,'Selector lied about connected server');
    assert(h.network.ws===ws,'Rendering server list reconnected');return {value:select.value,connectedURL:url,sameSocket:true};
  """)
  await check('Bounded diagnostics contain no account/chat/skin data',"""
    rp.capture.start({seconds:1,maxCells:2});for(let i=0;i<5;i++)T.frame();rp.capture.stop();
    const snapshot=rp.metrics.snapshot();assert(snapshot.windowFrames<=600,'Unbounded frame storage');assert(snapshot.errors===0,'Presentation exception');
    const capture=rp.capture.snapshot();assert(capture.frames===5,'Trace missing frames');
    assert(!p.logs.some(x=>x.event==='presentation-error'),'Production-frame exception');return {trace:capture,metrics:snapshot};
  """)
  await check('Tracker/assignment mismatch cancels queued multibox without invented slots',"""
    m.destroyAux();p.tracker.servers=[{id:'mismatch',host:h.network.url,name:'FFA fixture',mode:'ffa',region:'EU'}];
    h.world.myPlayerIDs=[100,101];h.packets.handshakeDone=true;m.intent={slot:1,createdAt:performance.now()};
    m.tick(performance.now());assert(!m.intent&&!m.aux&&!m.multi,'Wrong-width intent survived');
    return {assigned:2,expected:1,pending:null,nativeFallback:true};
  """)
  await page.wait_for_timeout(300)
  forbidden=[q for q in requests if any(x in q['url'] for x in ['ryuten.io','fonts.googleapis.com','fonts.gstatic.com','fontawesome.com','ipapi.co','pagead2.googlesyndication.com','https://senpa.io/web/assets/','https://senpa.io/web/img/','https://www.youtube.com/embed/'])]
  results.append({'case':'No core artwork, Ryuten, font, geolocation, advertising, or video-embed fetches in exercised paths','pass':not forbidden,'detail':forbidden})
  result={'artifactSha256':hashlib.sha256((ROOT/'dist/RYUTEN-Senpa.user.js').read_bytes()).hexdigest(),'scope':'Offline native parser and Pixi object integration; network/GPU substituted','cases':results,'pageErrors':errors,'requests':requests,'pass':all(x['pass'] for x in results) and not errors}
  (ROOT/'verification/senpa-acceptance.json').write_text(json.dumps(result,indent=2));await browser.close();return result['pass']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(main()) else 1)
