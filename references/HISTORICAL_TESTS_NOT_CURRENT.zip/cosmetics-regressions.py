# -*- coding: utf-8 -*-
"""Native Senpa cosmetics and Ryuten compositor regressions.

The browser is offline except for controlled tracker, GIF and hat fixtures.  The
captured native parser, native caches, native auxiliary realm and real Pixi
compositor are exercised; GPU submission is substituted and no pixels are
certified by this test.
"""
import shutil
import asyncio
import base64
import importlib.util
import json
import pathlib
import sys

from playwright.async_api import async_playwright

from browser_path import chromium_path
ROOT = pathlib.Path(__file__).resolve().parents[1]
CHROME = pathlib.Path(chromium_path())
EMOJI_URL = "https://api.senpa.io/fixture-cosmetics.gif"
HAT_URL = "https://api.senpa.io/fixture-cosmetics-hat.png"
MAP_URL = "https://i.imgur.com/aKvo1jQ.png"

# A deliberately tiny two-frame GIF.  The native yt decoder supplies the frame
# sheet, offsets and total duration used by both the canvas and Pixi paths.
GIF = base64.b64decode(
    "R0lGODlhBAAEAIEAAP8AAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQIBgAAACwAAAAABAAEAAAICQABCBxIsCCAgAAh+QQIDgAAACwAAAAABAAEAIEA/wAAAAAAAAAAAAAICQABCBxIsCCAgAA7"
)
PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
)

# Keep the cosmetic fixture inside the test packet itself.  This exercises the
# native fetch/decode path while remaining deterministic and independent of
# any network interception behavior in the browser harness.
EMOJI_URL = "data:image/gif;base64," + base64.b64encode(GIF).decode("ascii")
HAT_URL = "data:image/png;base64," + base64.b64encode(PNG).decode("ascii")

SPEC = importlib.util.spec_from_file_location("browser_smoke", ROOT / "tests" / "browser-smoke.py")
SMOKE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(SMOKE)


# Installed before a P2 request, just as the multibox regression harness does.
# The auxiliary document still runs the captured Senpa bundle and only its
# network transport is replaced by a controllable in-memory socket.
AUX_PREPARE = r'''() => {
  const port = SENPA_PORT;
  port.test.prepareAux = (w, p) => {
    const resolve = p.hostReadyResolve;
    p.hostReadyResolve = h => {
      resolve(h);
      const wait = () => {
        if (!h.wasm.create) {
          w.setTimeout(wait, 10);
          return;
        }
        h.wasm.create = (url, onOpen, onClose, onMessage, onError) => {
          const socket = {
            url, readyState: 0, sent: [],
            addEventListener() {},
            send(bytes) { this.sent.push([...new w.Uint8Array(bytes.buffer || bytes, bytes.byteOffset || 0, bytes.byteLength)]); },
            close() { this.readyState = 3; },
            open() { this.readyState = 1; onOpen(); },
            receive(bytes) { onMessage(new w.Uint8Array(bytes).buffer); },
            networkClose() { this.readyState = 3; onClose(); }
          };
          w.testSocket = socket;
          return socket;
        };
      };
      wait();
    };
  };
};'''


# This is evaluated after browser-fixtures.js.  It adds only packet writers and
# observation helpers; packet parsing and world construction remain native.
FIXTURE_SETUP = r'''() => {
  const {h, port, rp, r} = FIXTURE;
  const m = port.multibox;
  const T = {
    h, port, rp, r, m,
    emojiUrl: %s,
    hatUrl: %s,
    assert(condition, message) { if (!condition) throw Error(message); },
    near(a, b, epsilon = 1e-6) { return Math.abs(a - b) <= epsilon; },
    send(host, bytes) {
      const realm = host === h ? window : m.aux?.frame.contentWindow;
      if (!realm) throw Error('missing native realm for packet');
      host.parser.parse(new realm.Uint8Array(bytes).buffer);
    },
    waitCache: async (kind, url, host = h) => {
      const cache = kind === 'emoji' ? host.emojiCache : host.hatCache;
      const limit = performance.now() + 6000;
      while (performance.now() < limit) {
        const entry = cache.peek(url);
        if (entry?.state === 'ready') return entry;
        if (entry?.state === 'error') throw Error(kind + ' fixture decode failed for ' + url);
        await new Promise(resolve => setTimeout(resolve, 20));
      }
      const entry = cache.peek(url);
      throw Error(kind + ' fixture did not become ready: ' + JSON.stringify({state: entry?.state, url}));
    }
  };
  class Packet {
    constructor(op) { this.bytes = [op]; }
    u8(value) { this.bytes.push(value & 255); return this; }
    u16(value) { return this.u8(value).u8(value >> 8); }
    u32(value) { return this.u16(value).u16(value >>> 16); }
    i32(value) { return this.u32(value >>> 0); }
    s8(value) { this.u8(value.length); for (const c of value) this.u8(c.charCodeAt(0)); return this; }
    s16(value) { this.u8(value.length); for (const c of value) this.u16(c.charCodeAt(0)); return this; }
    send(host = h) { T.send(host, this.bytes); return this; }
  }
  T.Packet = Packet;
  T.assign = (host, client = 43, players = [101]) => {
    const packet = new Packet(0).u32(16000).u16(client).u8(players.length);
    for (const player of players) packet.u16(player);
    packet.send(host);
  };
  T.clientInfo = (host, rows) => {
    const packet = new Packet(10).u8(rows.length);
    for (const row of rows) {
      packet.u16(row.id).u8(row.bot ? 1 : 0).s16(row.nick).s16(row.tag || '')
        .u8(row.r).u8(row.g).u8(row.b).u8(0).s16(row.clan || '');
    }
    packet.u8(0).u8(0).send(host);
  };
  T.playerInfo = (host, rows) => {
    const packet = new Packet(11).u8(rows.length);
    for (const row of rows)
      packet.u16(row.id).u16(row.client).u8(row.r ?? 250).u8(row.g ?? 70).u8(row.b ?? 160).s8(row.skin || '').u32(row.hat || 0);
    packet.u8(0).u8(0).send(host);
  };
  T.playerHat = (host, player, hat) => new Packet(11).u8(0).u8(1).u16(player).u8(4).u32(hat).u8(0).send(host);
  T.world = (host, adds = [], updates = [], remove = [], eaten = []) => {
    const packet = new Packet(20).u16(eaten.length);
    for (const [a, b] of eaten) packet.u32(a).u32(b);
    packet.u16(adds.length);
    for (const cell of adds) {
      packet.u32(cell.id).i32(cell.x ?? 7000).i32(cell.y ?? 7000).u16(cell.radius ?? 100).u8(cell.type ?? 0);
      if ((cell.type ?? 0) === 0) packet.u16(cell.parent ?? 100).u8(cell.r ?? 240).u8(cell.g ?? 90).u8(cell.b ?? 180);
      else if (cell.type === 2) packet.u8(255).u8(40).u8(70);
    }
    packet.u16(updates.length);
    for (const cell of updates) packet.u32(cell.id).i32(cell.x).i32(cell.y).u16(cell.radius);
    packet.u16(remove.length); for (const id of remove) packet.u32(id);
    packet.send(host);
  };
  T.frame = () => {
    const now = performance.now();
    h.player.update(now); h.camera.update(); h.world.update(now);
    port.multibox?.tick(now); port.flushActions(); rp.frame(now);
  };
  T.view = id => {
    const entry = rp.world.cells.get(id);
    if (!entry) throw Error('missing Ryuten view for cell ' + id);
    entry.view._5792();
    return entry.view;
  };
  T.cssColor = (doc, color) => {
    const probe = doc.createElement('span'); probe.style.color = color; return probe.style.color;
  };
  // Keep the continuously scheduled native loop from racing deterministic
  // frameNow values.  Explicit T.frame() calls still run the production frame.
  port.onFrame = null;
  T.world(h, [
    {id: 10, parent: 100, x: 7000, y: 7000, radius: 120},
    {id: 12, parent: 102, x: 7200, y: 7000, radius: 90}
  ]); T.frame();
  window.COSMETICS_TEST = T;
  return {nativeEmojiCache: typeof h.emojiCache.get, nativeHatCache: typeof h.hatCache.get,
    nativeHatCatalog: typeof h.hatCatalog.get, compositor: typeof r.n_._7703,
    nativeEject: typeof r.Bt?._7703, nativeEjectLayer: typeof r.c_?._4659};
}'''


def evaluate_source(template: str) -> str:
    return template % (json.dumps(EMOJI_URL), json.dumps(HAT_URL))


async def main() -> bool:
    if not CHROME.is_file():
        raise FileNotFoundError(f"Chrome executable not found: {CHROME}")

    results = []
    page_errors = []
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            executable_path=str(CHROME),
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        try:
            page = await browser.new_page(viewport={"width": 1440, "height": 1000})
            page.set_default_timeout(15000)
            page.on("pageerror", lambda error: page_errors.append(str(error)))

            async def route(request):
                url = request.request.url
                if url.startswith("https://api.senpa.io/tracker"):
                    await request.fulfill(
                        status=200,
                        body=(ROOT / "references" / "tracker.json").read_text(encoding="utf-8"),
                        content_type="application/json",
                        headers={"Access-Control-Allow-Origin": "*"},
                    )
                elif url == EMOJI_URL:
                    await request.fulfill(status=200, body=GIF, content_type="image/gif",
                                          headers={"Access-Control-Allow-Origin": "*"})
                elif url in (HAT_URL, MAP_URL):
                    await request.fulfill(status=200, body=PNG, content_type="image/png",
                                          headers={"Access-Control-Allow-Origin": "*"})
                else:
                    await request.abort()

            await page.route("**/*", route)
            await page.set_content("<!doctype html><html><head></head><body></body></html>")
            await page.evaluate("(" + SMOKE.HOOK + ")()")
            await page.evaluate((ROOT / "dist" / "RYUTEN-Senpa.user.js").read_text(encoding="utf-8"))
            await page.wait_for_function("SENPA_PORT?.ready || SENPA_PORT?.error", timeout=30000)
            boot = await page.evaluate("() => ({ready: SENPA_PORT.ready, error: SENPA_PORT.error || null})")
            if not boot["ready"]:
                raise RuntimeError("native/ryuten bootstrap failed: " + str(boot))

            await page.evaluate((ROOT / "tests" / "browser-fixtures.js").read_text(encoding="utf-8"))
            await page.evaluate("() => FIXTURE.connect()")
            await page.evaluate(AUX_PREPARE)
            dist_script = (ROOT / "dist" / "RYUTEN-Senpa.user.js").read_text(encoding="utf-8")
            dist_sync_preferences = await page.evaluate("() => String(SENPA_PORT.multibox?.syncPreferences)")
            if "emojiSlots" not in dist_script or "emojiSlots" not in dist_sync_preferences:
                raise RuntimeError("built dist is stale: multibox.syncPreferences lacks emojiSlots synchronization")
            setup = await page.evaluate(evaluate_source(FIXTURE_SETUP))
            print("BOOT", json.dumps({"chrome": str(CHROME), "gpu": "submission substituted",
                "multiboxSourceFallback": False, **setup}, ensure_ascii=False), flush=True)

            async def check(name: str, source: str) -> None:
                try:
                    detail = await page.evaluate("async()=>{const T=COSMETICS_TEST,{h,port,rp,r,m}=T;" + source + "}")
                    results.append({"case": name, "pass": True, "detail": detail})
                    print("PASS", name, json.dumps(detail, ensure_ascii=False), flush=True)
                except Exception as error:
                    results.append({"case": name, "pass": False, "error": str(error)})
                    print("FAIL", name, str(error)[:1600], flush=True)

            await check("No-skin WindBine cells retain their server color", r'''
              const originalServers = port.tracker.servers, originalEnabled = m.enabled, originalColoring = r.Q.OWN_ORB_COLORING._5997();
              try {
                port.tracker.servers = [{host: h.network.url, name: 'WindBine', region: 'EU', mode: 'megasplit2', modeName: 'MegaSplitX'}];
                m.setEnabled(true);m.profile(0,{skinMode:'none'});m.profile(1,{skinMode:'none'});
                r.Q.OWN_ORB_COLORING._7531('default');
                T.world(h,[{id:10,parent:100,x:7000,y:7000,radius:120,r:20,g:200,b:60},{id:11,parent:101,x:7200,y:7000,radius:100,r:30,g:90,b:220},{id:12,parent:102,x:7400,y:7000,radius:90,r:220,g:80,b:40}]);T.frame();
                const own=rp.world.cells.get(10).view,parent=own._2182,stage=new r.c.W20();r.n_._6212();r.n_._7703(own,stage);
                T.assert(parent._3661 === '', 'no-skin profile still exposed a skin URL');
                T.assert(stage.children[0]?.tint === own._6728._1026, 'no-skin owned cell used the multibox accent instead of its server color');
                return {setting:r.Q.OWN_ORB_COLORING._5997(),cellColor:own._6728._1026,parentColor:parent._6728._1026,renderTint:stage.children[0]?.tint,skin:parent._3661,profile:m.profile(0)};
              } finally { port.tracker.servers=originalServers;r.Q.OWN_ORB_COLORING._7531(originalColoring);m.setEnabled(originalEnabled); }
            ''')

            await check("No-skin cells keep the native shield and its cell color", r'''
              const originalShield = r.pe._2874.shield, originalColoring = r.Q.OWN_ORB_COLORING._5997();
              const shield = Object.keys(r.pe._1763)[0];
              try {
                T.assert(shield, 'native shield catalog is empty');
                r.Me._2232(shield);
                m.profile(0,{skinMode:'none'});m.profile(1,{skinMode:'none'});
                r.Q.OWN_ORB_COLORING._7531('default');
                T.world(h,[{id:10,parent:100,x:7000,y:7000,radius:120,r:20,g:200,b:60},{id:11,parent:101,x:7200,y:7000,radius:100,r:30,g:90,b:220},{id:12,parent:102,x:7400,y:7000,radius:90,r:220,g:80,b:40}]);T.frame();
                const own=rp.world.cells.get(10).view,client=own._2182._1059,stage=new r.c.W20();
                r.n_._6212();r.n_._7703(own,stage);
                const tinted=stage.children.filter(sprite=>Number(sprite.tint)===own._6728._1026);
                T.assert(client._8313===shield, 'no-skin path removed the equipped shield');
                T.assert(stage.children.length>0 && tinted.length>0, 'shield/cell compositor lost the native cell color');
                return {shield,clientShield:client._8313,cellColor:own._6728._1026,children:stage.children.length,
                  matchingTintedChildren:tinted.length,childTints:stage.children.map(sprite=>Number(sprite.tint))};
              } finally { r.Me._2232(originalShield);r.Q.OWN_ORB_COLORING._7531(originalColoring); }
            ''')

            await check("Captured native packet 44 updates emoji state and decodes the embedded GIF", r'''
              const before = h.emojiCache.entries.size;
              new T.Packet(44).u16(41).u16(900).u16(3).s8(T.emojiUrl).send(h);
              const client = h.world.clientsList.get(41);
              T.assert(client.emojiUrl === T.emojiUrl, 'packet 44 URL was not applied to native client');
              T.assert(T.near(client.emojiUntil - client.emojiStartedAt, 900), 'packet 44 duration was not preserved');
              const entry = await T.waitCache('emoji', T.emojiUrl);
              T.assert(entry.animated && entry.frameCount === 2, 'native GIF was not decoded as two frames');
              T.assert(entry.sheet.width > 0 && entry.sheet.height > 0, 'native GIF sheet is empty');
              T.assert(entry.totalDuration > entry.offsets[1], 'native GIF timing metadata is invalid');
              return {cacheEntriesBefore: before, cacheEntryState: entry.state, frameCount: entry.frameCount,
                offsets: entry.offsets.slice(), totalDuration: entry.totalDuration, confirmedSlot: 3,
                duration: client.emojiUntil - client.emojiStartedAt};
            ''')

            await check("Emoji timing, expiry, hat sizes and cosmetic pool reset use native data", r'''
              r.Q.MULTIBOX_RING._7531(false); // Independent ring tested in acceptance suite; count only cosmetics here.
              const client = h.world.clientsList.get(41), entry = h.emojiCache.peek(T.emojiUrl);
              T.assert(entry?.state === 'ready' && entry.frameCount === 2, 'GIF fixture is not ready');
              const boundary = entry.offsets[1], total = entry.totalDuration;
              T.assert(h.emojiCache.frameIndexAt(entry, Math.max(0, boundary - 1)) === 0, 'first GIF frame timing wrong');
              T.assert(h.emojiCache.frameIndexAt(entry, boundary) === 1, 'second GIF frame timing wrong');
              T.assert(h.emojiCache.frameIndexAt(entry, total + boundary) === 1, 'GIF loop timing wrong');

              h.hatCatalog.entries.set(7, {url: T.hatUrl, scale: 175, offset_y: 25});
              h.hatCatalog.entries.set(8, {url: T.hatUrl, scale: 80, offset_y: -10});
              T.playerHat(h, 100, 7); T.playerHat(h, 102, 8); T.frame();
              const hatEntry = await T.waitCache('hat', T.hatUrl);
              T.assert(hatEntry.state === 'ready' && hatEntry.canvas.width > 0, 'native hat image was not decoded');

              const started = client.emojiStartedAt, until = client.emojiUntil, view10 = T.view(10), view12 = T.view(12);
              const sampleNow = started + 50; T.rp.motion.frameNow = sampleNow;
              const state = T.rp.emojiState(view10);
              T.assert(state.active && T.rp.emojiScale(view10) < 1, 'active emoji scale/fade did not use native lifetime');
              const frame = h.emojiCache.frameIndexAt(entry, state.now - started);
              T.assert(frame === 0 || frame === 1, 'emoji frame index was not selected from native timing');

              T.rp.cosmetics.begin(sampleNow);
              const stage10 = new r.c.W20(); T.rp.drawCosmetics(view10, stage10, 1);
              const stage12 = new r.c.W20(); T.rp.drawCosmetics(view12, stage12, 1);
              const expected10 = view10._1904 * 2 * 175 / 100;
              const expected12 = view12._1904 * 2 * 80 / 100;
              const hat10 = stage10.children.find(sprite => T.near(sprite.width, expected10));
              const hat12 = stage12.children.find(sprite => T.near(sprite.width, expected12));
              T.assert(hat10 && T.near(hat10.height, expected10), 'large hat size was not derived from radius/catalog scale');
              T.assert(hat12 && T.near(hat12.height, expected12), 'small hat size was not derived from radius/catalog scale');
              T.assert(T.near(hat10.y, view10._9202 + view10._1904 * 25 / 100), 'large hat offset was not applied');
              T.assert(T.near(hat12.y, view12._9202 - view12._1904 * 10 / 100), 'small hat offset was not applied');

              T.rp.motion.frameNow = until + 1; const expired = T.rp.emojiState(view10);
              T.assert(!expired.active && T.rp.emojiScale(view10) === 1, 'expired emoji remained active or scaled');
              const expiredStage = new r.c.W20(); T.rp.drawCosmetics(view10, expiredStage, 1);
              T.assert(expiredStage.children.length === 1, 'expired emoji sprite was still drawn alongside hat');

              const firstSprites = stage10.children.slice();
              T.rp.cosmetics.begin(sampleNow + 100);
              T.rp.motion.frameNow = sampleNow + 100;
              const pooledStage = new r.c.W20(); T.rp.drawCosmetics(view10, pooledStage, 1);
              T.assert(pooledStage.children.length === firstSprites.length, 'cosmetic pool changed draw count');
              T.assert(firstSprites.every(sprite => pooledStage.children.includes(sprite)),
                'cosmetic pool was not reset/reused: ' + JSON.stringify({first:firstSprites.length,
                  pooled:pooledStage.children.length, same:firstSprites.map(sprite => pooledStage.children.includes(sprite)),
                  records:[...T.rp.cosmetics.records.values()].map(record => ({kind:record.kind,index:record.index,pool:record.pool.length}))}));
              T.rp.cosmetics.reset();
              T.assert(T.rp.cosmetics.records.size === 0, 'cosmetic reset left pooled records behind');
              return {frames: entry.frameCount, offsets: entry.offsets.slice(), loopFrame: h.emojiCache.frameIndexAt(entry, total + boundary),
                activeScale: T.rp.emojiScale(view10), expired: !expired.active,
                hatSizes: [expected10, expected12], poolReused: true, recordsAfterReset: T.rp.cosmetics.records.size};
            ''')

            await check("Ejected type-2 cells sample native x/y/r/dt in both styles and draw at full alpha", r'''
              const id = 7002, oldStyle = rp.motion.style, oldFrameNow = rp.motion.frameNow;
              const oldAllyDim = r.ne._4551;
              const add = {id, type: 2, x: 7420, y: 7160, radius: 123};
              const update = {id, x: 7584, y: 7288, radius: 157};
              let view;
              const poses = {};
              const drawNativeEject = allyDim => {
                r.ne._4551 = !allyDim;
                const direct = r.Bt && typeof r.Bt._7703 === 'function';
                const stage = direct ? new r.c.W20() : r.c_._4435;
                if (direct) { r.Bt._6212(); r.Bt._7703(view, stage); }
                else r.c_._4659();
                const children = stage.children.filter(sprite =>
                  T.near(sprite.position.x, view._7847) && T.near(sprite.position.y, view._9202) &&
                  T.near(sprite.width, view._1904 * 2) && T.near(sprite.height, view._1904 * 2));
                T.assert(children.length === 1, 'native eject layer did not emit one exact 2-radius sprite: ' + children.length);
                const sprite = children[0];
                return {alpha: sprite.alpha, width: sprite.width, height: sprite.height,
                  x: sprite.position.x, y: sprite.position.y};
              };
              try {
                T.world(h, [add]); T.frame();
                const cell = h.world.cells.get(id);
                T.assert(cell && cell.type === 2, 'native packet 20 did not create a type-2 eject cell');
                T.world(h, [], [update]);
                for (const style of ['Senpa', 'Ryuten']) {
                  if (rp.motion.style !== style) r.Q.PRESENTATION_STYLE._7531(style);
                  T.frame();
                  view = T.view(id);
                  const native = {x: cell.x, y: cell.y, r: cell.radius, dt: cell.dt};
                  const pose = rp.motion.sample(cell, rp.motion.frameNow);
                  T.assert(T.near(pose.x, native.x) && T.near(pose.y, native.y) && T.near(pose.r, native.r) &&
                    T.near(pose.u, native.dt), style + ' eject sample diverged from native source: ' + JSON.stringify({pose, native}));
                  poses[style] = {x: pose.x, y: pose.y, r: pose.r, dt: pose.u};
                }
                view = T.view(id);
                T.assert((r.Bt && typeof r.Bt._7703 === 'function') ||
                  (r.c_ && r.c_._4435 && typeof r.c_._4659 === 'function'),
                  'native eject compositor Bt/layer is not exposed');
                const immediate = drawNativeEject(false);
                const dimmed = drawNativeEject(true);
                T.assert(T.near(immediate.alpha, 1), 'eject compositor birth draw was not alpha 1: ' + immediate.alpha);
                T.assert(T.near(dimmed.alpha, 1), 'eject compositor ally-dim draw was not alpha 1: ' + dimmed.alpha);
                T.assert(T.near(immediate.width, view._1904 * 2) && T.near(immediate.height, view._1904 * 2), 'immediate eject diameter changed');
                T.assert(T.near(dimmed.width, view._1904 * 2) && T.near(dimmed.height, view._1904 * 2), 'ally-dim eject diameter changed');
                const native = {x: cell.x, y: cell.y, r: cell.radius, dt: cell.dt};
                return {native, poses, immediate, allyDim: dimmed, radiusDiameter: view._1904 * 2,
                  compositor: r.Bt && typeof r.Bt._7703 === 'function' ? 'r.Bt' : 'r.c_._4435'};
              } finally {
                r.ne._4551 = oldAllyDim;
                if (rp.motion.style !== oldStyle) r.Q.PRESENTATION_STYLE._7531(oldStyle);
                rp.motion.frameNow = oldFrameNow;
                T.world(h, [], [], [id]); T.frame();
              }
            ''')

            await check("Actual Pixi compositor tints names and mass after a pooled reset", r'''
              const source = h.world.clientsList.get(41), originalColor = source.teamColor;
              const saved = {cellNick: h.settings.cellNick, cellMass: h.settings.cellMass,
                ownCellNick: h.settings.ownCellNick, ownCellMass: h.settings.ownCellMass,
                cellSkin: h.settings.cellSkin, enemyCellSkin: h.settings.enemyCellSkin};
              const renderText = (view, stage) => {
                r.n_._6212(); view._5792(); r.n_._7703(view, stage);
                // Mass is a Pixi Container; its individual digit sprites are tinted.
                return stage.children.flatMap(sprite=>sprite.children?.length?sprite.children:[sprite]).filter(sprite => Number(sprite.tint) === T.expectedTint);
              };
              try {
                h.settings.cellNick = true; h.settings.cellMass = true; h.settings.ownCellNick = true; h.settings.ownCellMass = true;
                h.settings.cellSkin = false; h.settings.enemyCellSkin = false;
                source.teamColor = '#12ab34'; source._senpaNameColor = source.teamColor; T.frame();
                const view = T.view(10); T.expectedTint = 0x12ab34;
                T.assert(T.rp.nameTint(view) === T.expectedTint, 'nameTint did not read client _senpaNameColor');
                const firstStage = new r.c.W20(), first = renderText(view, firstStage);
                T.assert(first.length >= 2, 'actual compositor did not emit both name and mass sprites: ' + JSON.stringify({
                  children:firstStage.children.map(sprite => ({tint:sprite.tint,text:sprite.text,alpha:sprite.alpha,visible:sprite.visible,childCount:sprite.children?.length||0})),
                  settings:{nick:h.settings.cellNick,mass:h.settings.cellMass,ownNick:h.settings.ownCellNick,ownMass:h.settings.ownCellMass},
                  view:{type:view._7926,radius:view._1904,owner:view._2182?._1059?._6988},sourceColor:source._senpaNameColor}));
                T.assert(first.every(sprite => Number(sprite.tint) === T.expectedTint), 'first pooled text pass has wrong tint');
                const firstChildren = firstStage.children.slice();

                source.teamColor = '#d946ef'; source._senpaNameColor = source.teamColor; T.frame(); T.expectedTint = 0xd946ef;
                T.assert(T.rp.nameTint(T.view(10)) === T.expectedTint, 'updated client color did not reach nameTint');
                const secondStage = new r.c.W20(), second = renderText(T.view(10), secondStage);
                T.assert(second.length >= 2, 'pooled compositor lost name or mass sprite');
                T.assert(second.every(sprite => Number(sprite.tint) === T.expectedTint), 'pooled name/mass sprite retained stale tint');
                return {firstTint: 0x12ab34, secondTint: 0xd946ef, firstSprites: first.length,
                  secondSprites: second.length, poolReused: secondStage.children.some(sprite => firstChildren.includes(sprite))};
              } finally {
                Object.assign(h.settings, saved); source.teamColor = originalColor; T.frame();
                delete T.expectedTint;
              }
            ''')

            await check("HUD preserves server colors and renders untrusted nicknames as text", r'''
              const oldTeam = port.teamlist, oldLeaderboard = port.leaderboard;
              const teamNick = '<img src=x onerror="window.__cosmeticsPwned=1">';
              const leaderboardNick = '<svg onload="window.__cosmeticsPwned=1">bad</svg>';
              const doc = port.frame.contentDocument;
              doc.defaultView.__cosmeticsPwned = false;
              try {
                port.teamlist = [{nick: teamNick, mass: 123, location: 'A1', color: '#123456'}];
                port.leaderboard = [{nick: leaderboardNick, mass: 456, color: '#abcdef'}];
                T.rp.updateHUD();
                const team = doc.querySelector('#senpa-team'), teamRow = [...team.children].find(node => node.tagName === 'DIV');
                const leaderboardRow = doc.querySelector('#leaderboard .leaderboard-entry');
                T.assert(teamRow && leaderboardRow, 'HUD rows were not rendered');
                T.assert(teamRow.firstElementChild.textContent === teamNick, 'team nickname was not preserved as text');
                T.assert(leaderboardRow.textContent.includes('1. ' + leaderboardNick), 'leaderboard nickname was not preserved as text');
                T.assert(!teamRow.querySelector('img') && !leaderboardRow.querySelector('svg'), 'untrusted nick became markup');
                T.assert(doc.defaultView.__cosmeticsPwned === false, 'untrusted HUD nickname executed markup');
                T.assert(teamRow.firstElementChild.style.color === T.cssColor(doc, '#123456'), 'team HUD color was dropped');
                T.assert(leaderboardRow.style.color === T.cssColor(doc, '#abcdef'), 'leaderboard HUD color was dropped');
                return {teamText: teamRow.firstElementChild.textContent, leaderboardText: leaderboardRow.textContent,
                  teamColor: teamRow.firstElementChild.style.color, leaderboardColor: leaderboardRow.style.color};
              } finally { port.teamlist = oldTeam; port.leaderboard = oldLeaderboard; T.rp.updateHUD(); }
            ''')

            await check("FFA toggle is present while assignment width is enforced", r'''
              T.assert(!!r.Q.FFA_MULTIBOX_ENABLED,'FFA toggle missing');
              const originalServers=port.tracker.servers;
              try{port.tracker.servers=[{id:1,host:h.network.url,mode:'ffa',region:'EU',name:'Fixture FFA'}];
                T.assert(m.isSupported,'FFA not recognized');T.assert(!m.multi,'Two-slot assignment incorrectly accepted as one-slot FFA');
                return {ffaSetting:true,assignmentGuard:true};
              }finally{port.tracker.servers=originalServers;}
            ''')

            await check("No unhandled production-frame exceptions", r'''
              const failures = port.logs.filter(item => item.event === 'presentation-error');
              T.assert(!failures.length, JSON.stringify(failures));
              return {frames: rp.world.frameCount, nativeEmojiEntries: h.emojiCache.entries.size,
                nativeHatEntries: h.hatCache.entries.size};
            ''')

            summary = {
                "scope": "Offline native cosmetics integration",
                "network": "Fixture tracker/GIF/PNG responses",
                "gpu": "Submission substituted; no pixel certification",
                "cases": results,
                "pageErrors": page_errors,
                "pass": all(item["pass"] for item in results) and not page_errors,
            }
            print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
            (ROOT/'verification/cosmetics-regressions.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
            return summary["pass"]
        finally:
            await browser.close()


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(0 if asyncio.run(main()) else 1)
