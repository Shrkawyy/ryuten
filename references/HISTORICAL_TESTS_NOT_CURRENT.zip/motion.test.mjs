import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
const code=fs.readFileSync(new URL('../src/app/motion.js',import.meta.url),'utf8');
function setup(style='Senpa'){
 let now=1000;const saved={};
 class Setting{constructor(value){this.value=value;this.f=[];} _5997(){return this.value;} _4935(_,fn){this.f.push(fn);} set(v){this.value=v;for(const f of this.f)f(v);}}
 class Cell{constructor(type=0){Object.assign(this,{type,x:0,y:10,radius:20,startX:0,startY:10,startRadius:20,endX:0,endY:10,endRadius:20,updateTime:1000,dt:1,removed:false});}update(x,y,r,t){this.startX=this.x;this.startY=this.y;this.startRadius=this.radius;this.endX=x;this.endY=y;this.endRadius=r;this.updateTime=t;}}
 const camera={x:100,y:200,zoom:.3,targetZoom:.5,onMouseWheel(e){this.targetZoom*=e.deltaY>0?.9:1/.9;}};
 const h={Cell,world:{cells:new Map()},network:{isReplay:false},camera,settings:{cellAnimation:120,cameraSpeed:20,zoomSpeed:.9}};
 const r={Q:{PRESENTATION_STYLE:new Setting(style),ELEMENT_ANIMATION_SOFTENING:new Setting(160),XPLUS_SETTLE_MS:new Setting(140)}};
 const rp={modules:{},parentPort:{mode:'ryuten'},saveSetting:(k,v)=>saved[k]=v};const context={window:{RYUTEN_PORT:rp},parent:{performance:{now:()=>now}}};vm.runInNewContext(code,context);
 const motion=new rp.modules.MotionProfiles(h,r);return {h,r,rp,motion,saved,now:t=>now=t,axis:rp.modules.xplusAxis};
}
const near=(a,b,tol=1e-7)=>assert.ok(Math.abs(a-b)<=tol,`${a} != ${b}`);
test('Senpa is the default; motion owns no camera integrator',()=>{const t=setup();assert.equal(t.motion.style,'Senpa');assert.equal(t.motion.camera(),false);assert.equal(t.motion.snapshot().cameraDivisor,11);});
for(const style of ['Senpa','Ryuten','XPLUS'])test(style+' profile always uses exact native pellet pose and lifetime',()=>{const t=setup(style),c=new t.h.Cell(2);Object.assign(c,{x:51,y:19,radius:22,dt:.37});const p=t.motion.sample(c,2000);near(p.x,51);near(p.y,19);near(p.r,22);near(p.u,.37);c.removed=true;near(t.motion.sample(c,2500).u,.37);});
test('Ryuten packet-linear response reaches half way at half delay',()=>{const t=setup('Ryuten'),c=new t.h.Cell();c.update(100,50,40,1000);const p=t.motion.sample(c,1080);near(p.x,50);near(p.y,30);near(p.r,30);near(t.motion.sample(c,1160).x,100);});
test('Ryuten interrupted target starts at the sampled old trajectory',()=>{const t=setup('Ryuten'),c=new t.h.Cell();c.update(100,10,20,1000);c.update(200,10,20,1080);near(t.motion.sample(c,1080).x,50);near(t.motion.sample(c,1160).x,125);});
test('XPLUS declared 95-percent stationary step settling is measured',()=>{const t=setup();const[x]=t.axis(0,0,100,140,140);near(x,95,1e-6);});
for(const hz of [60,120,144,240])test('XPLUS exact held-target step is stable at '+hz+' Hz',()=>{const {axis}=setup();let x=0,v=0,time=0;while(time<140){const dt=Math.min(1000/hz,140-time);[x,v]=axis(x,v,100,dt,140);time+=dt;}near(x,95,1e-6);});
test('XPLUS repeated same-frame sampling is idempotent',()=>{const t=setup('XPLUS'),c=new t.h.Cell();c.update(100,40,35,1000);const p={...t.motion.sample(c,1060)},p2=t.motion.sample(c,1060);near(p.x,p2.x);near(p.vx,p2.vx);});
test('XPLUS target reversal stays between current and authoritative target',()=>{const {axis}=setup();let[x,v]=axis(0,0,100,60,140);for(let i=0;i<100;i++){const old=x;[x,v]=axis(x,v,-50,1000/144,140);assert.ok(x>=-50&&x<=old);}assert.ok(x<0);});
test('Removed cells use native death progress even with slow XPLUS',()=>{const t=setup('XPLUS'),c=new t.h.Cell();c.update(100,50,30,1000);c.removed=true;c.dt=1;near(t.motion.sample(c,1050).u,1);});
test('All style changes preserve camera state and saved native controls',()=>{const t=setup(),before=JSON.stringify(t.h.camera),settings=JSON.stringify(t.h.settings);for(const s of ['Ryuten','XPLUS','Senpa','XPLUS']){t.r.Q.PRESENTATION_STYLE.set(s);assert.equal(JSON.stringify(t.h.camera),before);assert.equal(JSON.stringify(t.h.settings),settings);}assert.equal(t.saved['motion-style'],'XPLUS');});
test('Replay always reads native cell pose',()=>{const t=setup('XPLUS'),c=new t.h.Cell();c.update(100,0,20,1000);c.x=27;t.h.network.isReplay=true;near(t.motion.sample(c,1040).x,27);});
test('Native wheel changes native target, no Ryuten target is created',()=>{const t=setup('Ryuten');t.motion.wheel({deltaY:1});near(t.h.camera.targetZoom,.45);});
test('Clock reversal cannot rewind a previously sampled pose',()=>{const t=setup('XPLUS'),c=new t.h.Cell();c.update(100,10,20,1000);const x=t.motion.sample(c,1100).x;near(t.motion.sample(c,1050).x,x);});
test('Cross-source rebind preserves pose without camera movement',()=>{const t=setup('XPLUS'),a=new t.h.Cell(),b=new t.h.Cell();a.update(100,0,20,1000);b.endX=150;const x=t.motion.sample(a,1060).x;t.motion.rebind(a,b,1060);near(t.motion.sample(b,1060).x,x);});
