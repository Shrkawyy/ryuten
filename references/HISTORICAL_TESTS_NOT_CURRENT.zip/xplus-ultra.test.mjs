import test from 'node:test';import assert from 'node:assert/strict';
import {setup} from './motion-fixture.mjs';
const near=(a,b,tol=1e-7)=>assert.ok(Math.abs(a-b)<=tol,`${a} != ${b}`);
const move=(t,duration,hz=120)=>{for(let at=1000+1000/hz;at<=1000+duration;at+=1000/hz){t.motion.frameNow=at;t.motion.camera();}};
test('ULTRA defaults to 420 ms; radius, camera, zoom ratios are explicit',()=>{
 const t=setup('XPLUS'),s=t.motion.snapshot();assert.equal(s.delayMs,420);near(s.xplusCameraSettleMs,651);near(s.xplusZoomSettleMs,882);assert.equal(s.physicsOwner,'Senpa server');
});
test('Filter stages and output remain inside the historical target envelope',()=>{
 const {filter,stage}=setup(),s=stage(0);let min=0,max=0,seed=42;
 for(let i=0;i<10000;i++){seed=(1664525*seed+1013904223)>>>0;const target=seed/2**32*2000-1000;min=Math.min(min,target);max=Math.max(max,target);filter(s,target,1+(seed%50),120+seed%1880);for(const v of Object.values(s))assert.ok(Number.isFinite(v)&&v>=min-1e-9&&v<=max+1e-9);}
});
test('Analytic filter is subdivision independent across held-target intervals',()=>{
 const {filter,stage}=setup(),a=stage(4),b=stage(4);filter(a,500,150,420);for(let i=0;i<15;i++)filter(b,500,10,420);for(const k of ['a','b','c'])near(a[k],b[k]);
});
test('Invalid targets and elapsed times cannot contaminate filter state',()=>{
 const {filter,stage}=setup(),s=stage(10);for(const bad of [NaN,Infinity,-Infinity]){filter(s,bad,16,420);filter(s,100,bad,420);}for(const v of Object.values(s))near(v,10);
});
test('Large background gap takes a bounded visual step, not a teleport',()=>{
 const t=setup('XPLUS'),c=new t.h.Cell();c.update(10000,10,20,1000);const p=t.motion.sample(c,31000);assert.ok(p.x>0&&p.x<1000);assert.equal(p.last,31000);const x=p.x;near(t.motion.sample(c,31000).x,x);
});
test('Native game cell positions, targets and lifetime are never rewritten by sampling',()=>{
 const t=setup('XPLUS'),c=new t.h.Cell();c.update(100,500,80,1000);const before=JSON.stringify(c);for(let i=0;i<100;i++)t.motion.sample(c,1000+i*16);assert.equal(JSON.stringify(c),before);
});
test('Visible camera/zoom can lag while native camera and settings remain identical',()=>{
 const t=setup('XPLUS');assert.equal(t.motion.camera(),true);t.h.camera.x=1100;t.h.camera.y=2200;t.h.camera.zoom=.6;
 const before=JSON.stringify(t.h.camera),settings=JSON.stringify(t.h.settings);move(t,200);
 assert.ok(t.motion.ultraView.x>100&&t.motion.ultraView.x<1100);assert.ok(t.motion.ultraView.zoom>.3&&t.motion.ultraView.zoom<.6);
 assert.equal(JSON.stringify(t.h.camera),before);assert.equal(JSON.stringify(t.h.settings),settings);near(t.r.z_._3852._7847,t.motion.ultraView.x);
});
test('Camera uses visible living own-cell center, not disappearing cells',()=>{
 const t=setup('XPLUS'),own=new t.h.Cell(),dead=new t.h.Cell();Object.assign(own,{x:600,endX:600,y:400,endY:400});Object.assign(dead,{x:100000,endX:100000,removed:true});t.h.world.myCells=[new Map([[1,own],[2,dead]])];t.motion.camera();move(t,2500);
 near(t.motion.ultraView.x,600,.01);near(t.motion.ultraView.y,400,.01);
});
test('Log zoom remains strictly positive through 100x zoom reversal',()=>{
 const t=setup('XPLUS');t.motion.camera();for(let i=0;i<2000;i++){t.h.camera.zoom=i%240<120?.02:2;t.motion.frameNow=1000+i*8;t.motion.camera();assert.ok(t.motion.ultraView.zoom>=.02-1e-10&&t.motion.ultraView.zoom<=2+1e-10);}
});
test('Same-frame camera sampling is idempotent',()=>{
 const t=setup('XPLUS');t.motion.camera();t.h.camera.x=3000;t.motion.frameNow=1016;t.motion.camera();const before=JSON.stringify(t.motion.ultraView);for(let i=0;i<50;i++)t.motion.camera();assert.equal(JSON.stringify(t.motion.ultraView),before);
});
test('Mouse projection reads rendered transform and restores native state',()=>{
 const t=setup('XPLUS');t.motion.camera();t.h.camera.x=1100;t.motion.frameNow=1016;t.motion.camera();const before=JSON.stringify(t.h.camera),sent=t.h.actions.sendMouse();near(sent.x,t.motion.ultraView.x);near(sent.zoom,t.motion.ultraView.zoom);assert.equal(JSON.stringify(t.h.camera),before);
});
test('Projection restoration runs even if native input throws',()=>{
 const t=setup();t.h.actions.sendMouse=()=>{throw Error('fixture failure');};t.motion.installInputProjection();t.motion.select('XPLUS');t.motion.camera();t.h.camera.x=1100;const before=JSON.stringify(t.h.camera);assert.throws(()=>t.h.actions.sendMouse(),/fixture failure/);assert.equal(JSON.stringify(t.h.camera),before);
});
test('Native/replay modes bypass cinematic camera and input',()=>{
 for(const mode of ['native','replay']){const t=setup('XPLUS');t.motion.camera();t.h.camera.x=4321;if(mode==='native')t.rp.parentPort.mode='native';else t.h.network.isReplay=true;assert.equal(t.motion.camera(),false);assert.equal(t.h.actions.sendMouse().x,4321);assert.equal(t.motion.ultraView,null);}
});
test('Ryuten and Senpa bypass the new camera and keep native mouse projection',()=>{
 for(const profile of ['Ryuten','Senpa']){const t=setup(profile);assert.equal(t.motion.camera(),false);assert.equal(t.h.actions.sendMouse().x,t.h.camera.x);}
});
test('Profile switches and reset discard XPLUS history rather than leaking it into other styles',()=>{
 const t=setup('XPLUS');t.motion.camera();t.motion.select('Senpa');assert.equal(t.motion.ultraView,null);assert.equal(t.motion.camera(),false);t.motion.select('XPLUS');t.motion.camera();t.motion.reset();assert.equal(t.motion.ultraView,null);
});
test('Rebind keeps all three filter stages and derivatives',()=>{
 const t=setup('XPLUS'),a=new t.h.Cell(),b=new t.h.Cell();a.update(100,200,50,1000);b.endX=300;t.motion.sample(a,1060);const old=t.motion.records.get(a);t.motion.rebind(a,b,1060);const n=t.motion.records.get(b);for(const k of ['fx','fy','fr'])for(const f of ['a','b','c'])near(n[k][f],old[k][f]);
});
test('Ultra preset controls only presentation style and its test-specific setting',()=>{
 const t=setup(),camera=JSON.stringify(t.h.camera),settings=JSON.stringify(t.h.settings);t.motion.useUltraPreset(800);assert.equal(t.motion.style,'XPLUS');assert.equal(t.motion.delay,800);assert.equal(JSON.stringify(t.h.camera),camera);assert.equal(JSON.stringify(t.h.settings),settings);
});
