"""Real account adapter/UI with native reactive store and fixture API/OAuth popup."""
import asyncio, importlib.util, json, pathlib, shutil
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('smoke',ROOT/'tests/browser-smoke.py')
smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)

async def run():
 results=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=chromium_path(),headless=True)
  page=await browser.new_page(viewport={'width':1440,'height':1000});page.set_default_timeout(8000)
  async def route(rt):
   if rt.request.url.startswith('https://api.senpa.io/tracker'):
    await rt.fulfill(body=(ROOT/'references/tracker.json').read_text(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
   else:await rt.abort()
  await page.route('**/*',route);await page.set_content('<html><body></body></html>')
  await page.evaluate('('+smoke.HOOK+')()');await page.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text(encoding='utf8'))
  await page.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
  assert await page.evaluate('SENPA_PORT.ready'),await page.evaluate('SENPA_PORT.error')
  await page.evaluate((ROOT/'tests/browser-fixtures.js').read_text());await page.evaluate('FIXTURE.connect()')
  frame=await(await page.locator('#ryuten-senpa-frame').element_handle()).content_frame()
  async def check(name,code):
   try:
    detail=await page.evaluate('async()=>{const {h,port,rp,r,assert,Writer,world,advance,sent}=FIXTURE;'+code+'}')
    results.append({'case':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
   except Exception as error:
    results.append({'case':name,'pass':False,'error':str(error)});print('FAIL',name,str(error),flush=True)
  await frame.locator('#senpa-account button').first.click()
  await check('Normal login button opens Ryuten account without native-menu handoff',"""
    assert(port.mode==='ryuten','Revealed native menu');assert(rp.account.state.open,'Account panel not open');return port.mode;
  """)
  await check('Discord and Facebook use the native authentication bridge without menu handoff',"""
    let opened;const original=window.open;window.open=(url,name,features)=>{opened={url,name,features};return {closed:false,focus(){}};};
    try{assert(typeof h.accountLogin==='function','Missing direct native authentication bridge');
      const urls=[];for(const provider of ['discord','facebook']){opened=null;await rp.account.openAuth(provider);const expected=provider==='discord'?h.config.endPoints.authDiscord:h.config.endPoints.authFacebook;
        assert(opened?.url===expected,'Not native '+provider+' provider URL');assert(port.mode==='ryuten','Auth changed game surface');urls.push(opened.url);}return urls;
    }finally{if(window.login?.windowObjectReference)window.login.windowObjectReference.closed=true;window.open=original;}
  """)
  await page.keyboard.press('Escape')
  await check('Account Escape closes only the account panel',"""
    assert(!rp.account.state.open,'Account still open');assert(r.rs._9222.length===1,'Escape also closed main menu');return true;
  """)
  await check('Prepare authenticated native account fixture',"""
    port.testAccount={id:900,real_name:'Fixture <img onerror=alert(1)>',experience:100000,coins:50,
      skin_profiles:[{skin_id_1:11,skin_id_2:12}],skin_routes:{11:'fixture-own-1.png',12:'fixture-own-2.png'},favorites:[],
      hat_profiles:[{hat_id_1:null,hat_id_2:null}],hat_images:{},emoji_slots:[null,null,null,null]};
    h.account.request=async path=>path==='/account/'?JSON.parse(JSON.stringify(port.testAccount)):path.startsWith('/skins/')?{results:[{id:21,skin_name:'Fixture selectable skin',skin_route:'fixture-selected.png',requirement_type:0,requirement_data:'0'}]}:{success:true,results:{hats:[],emojis:[]}};
    h.account.requestJson=async(path,payload)=>{port.lastAccountWrite={path,payload};return {success:true};};
    const jwt='e30.'+btoa(JSON.stringify({exp:Math.floor(Date.now()/1000)+3600})).replace(/=+$/,'')+'.Zml4dHVyZQ';
    h.account.setToken(jwt);h.store.account=port.testAccount;await rp.account.refresh();return true;
  """)
  await frame.locator('#change-skin-1').click()
  await frame.locator('[data-account-kind="skin"][data-item-id="21"] [data-account-action="equip-skin"]').click()
  await page.wait_for_function('SENPA_PORT.child.reference.Be._4564[1]==="https://api.senpa.io/u/fixture-selected.png"')
  await check('Skin button stays within Ryuten and equips the correct native profile slot',"""
    assert(port.mode==='ryuten'&&rp.account.state.open,'Skin button handed off to native menu');
    rp.syncAccountSkins();
    assert(port.lastAccountWrite.path==='/account/save-profile','Wrong skin save endpoint');
    assert(port.lastAccountWrite.payload.profile.route1==='fixture-own-1.png','Overwrote other slot');
    assert(port.lastAccountWrite.payload.profile.route2==='fixture-selected.png','Wrong skin slot');
    assert(r.Be._4564[1]==='https://api.senpa.io/u/fixture-selected.png','Preview not updated');return port.lastAccountWrite;
  """)
  await frame.locator('[data-account-action="clear-current-skin"]').click()
  await page.wait_for_function('SENPA_PORT.child.reference.Be._4564[1]===""')
  await check('Explicit remove-current-skin clears only the selected authenticated slot',"""
    assert(port.lastAccountWrite.path==='/account/save-profile','Wrong removal endpoint');
    assert(port.lastAccountWrite.payload.profile.route1==='fixture-own-1.png','Removal touched other slot');
    assert(port.lastAccountWrite.payload.profile.route2==='','Selected slot not cleared');
    assert(r.Be._4564[1]===''&&r.Be._4564[0].endsWith('fixture-own-1.png'),'Previews wrong after removal');
    return {selectedSlot:1,otherSlotPreserved:true,nativeSave:true};
  """)
  await check('Rejected skin save leaves the native selected skin unchanged',"""
    const before=JSON.stringify(h.store.account.skin_profiles),original=h.account.requestJson;
    h.account.requestJson=async()=>({error:'save_failed'});let failed=false;
    try{await rp.account.equipSkin(1,rp.accountUtils.normalizeSkin({id:22,skin_name:'Rejected',skin_route:'fixture-rejected.png',requirement_type:0,requirement_data:'0'},h));}catch{failed=true;}finally{h.account.requestJson=original;}
    assert(failed,'Failure not surfaced');assert(JSON.stringify(h.store.account.skin_profiles)===before,'Failed save mutated selected skin');return true;
  """)
  await check('Account labels remain escaped text and normal panel never reveals native menu',"""
    await rp.account.open('account');assert(port.mode==='ryuten','Native handoff');
    assert(!port.frame.contentDocument.querySelector('#senpa-account img[onerror]'),'Account label injected HTML');
    const errors=port.logs.filter(x=>x.event==='presentation-error');assert(!errors.length,JSON.stringify(errors));return true;
  """)
  await frame.locator('.ryuten-account-header h2').wait_for(state='visible')
  await frame.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
  print('PANEL',await frame.locator('#ryuten-account-panel').evaluate('(el)=>({html:el.innerHTML.length,rect:el.getBoundingClientRect().toJSON(),display:getComputedStyle(el).display,visibility:getComputedStyle(el).visibility,opacity:getComputedStyle(el).opacity,background:getComputedStyle(el).backgroundColor})'),flush=True)
  await frame.locator('#ryuten-account-panel').screenshot(path=str(ROOT/'verification/account-panel-detail.png'))
  await page.screenshot(path=str(ROOT/'verification/account-panel.png'))
  output={'network':'fixture API and OAuth popup','gpu':'substituted submission','cases':results,'pass':all(x['pass'] for x in results)}
  (ROOT/'verification/account-browser-regressions.json').write_text(json.dumps(output,indent=2),encoding='utf8')
  await browser.close();return output['pass']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(run()) else 1)
