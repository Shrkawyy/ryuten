"""Experimental XPLUS on the actual packaged native engine/Pixi scene.
Network and GPU submission are substituted; this is not a visual-quality/FPS test.
"""
import asyncio, importlib.util, json, pathlib, hashlib
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('smoke',ROOT/'tests/browser-smoke.py')
smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
async def main():
 results=[];errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=chromium_path(),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1440,'height':1000})
  page.on('pageerror',lambda e:errors.append(str(e)))
  async def route(q):
   if q.request.url.startswith('https://api.senpa.io/tracker'):
    await q.fulfill(body=(ROOT/'references/tracker.json').read_text(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
   else:await q.abort()
  await page.route('**/*',route)
  await page.set_content('<!doctype html><html><body></body></html>')
  await page.evaluate('('+smoke.HOOK+')()')
  await page.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text())
  await page.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
  if not await page.evaluate('SENPA_PORT.ready'):raise RuntimeError(await page.evaluate('SENPA_PORT.error'))
  await page.evaluate((ROOT/'tests/browser-fixtures.js').read_text())
  await page.evaluate('''()=>{const {h,port,rp,r,world,advance}=FIXTURE;FIXTURE.connect();world([{id:500,x:7500,y:8000,radius:100,parent:100},{id:600,x:7800,y:8000,radius:90,parent:101}]);advance();port.onFrame=null;rp.hideMenu();}''')
  async def check(name,body):
   try:
    detail=await page.evaluate('async()=>{const {h,port,rp,r,world,advance,assert}=FIXTURE;'+body+'}')
    results.append({'case':name,'pass':True,'detail':detail});print('PASS',name,detail,flush=True)
   except Exception as e:
    results.append({'case':name,'pass':False,'error':str(e)});print('FAIL',name,str(e),flush=True)
  await check('Packaged UI selects XPLUS and exposes independent 120–2000 ms slider',r'''
    const before=h.settings.cellAnimation;r.Q.XPLUS_SETTLE_MS._7531(420);r.Q.PRESENTATION_STYLE._7531('XPLUS');rp.refreshMotionUI();
    const range=port.frame.contentDocument.querySelector('[data-senpa-animation]');
    assert(range.min==='120'&&range.max==='2000'&&range.step==='10','Wrong ultra UI limits');
    assert(range.value==='420'&&h.settings.cellAnimation===before,'Native preference overwritten');
    assert(port.frame.contentDocument.getElementById('client-version').textContent.includes('XPLUS Ultra Test'),'Missing experimental HUD');
    return rp.motion.snapshot();
  ''')
  await check('Native source cells unchanged while real Pixi views take the slower trajectory',r'''
    const c=h.world.cells.get(500);c.x=c.startX=c.endX=7500;c.y=c.startY=c.endY=8000;c.radius=c.startRadius=c.endRadius=100;
    rp.motion.reset();rp.motion.frameNow=10000;rp.world.sync();c.update(8500,8400,180,10000);
    const state=JSON.stringify({x:c.x,y:c.y,r:c.radius,ex:c.endX,ey:c.endY,er:c.endRadius});
    for(let t=10000;t<=10420;t+=10){rp.motion.frameNow=t;rp.world.sync();}
    const view=rp.world.cells.get(500).view,output=view._7847-rp.world.offset;
    assert(Math.abs(output-8450)<1e-5,'Three-stage step not rendered at 95%: '+output);
    assert(state===JSON.stringify({x:c.x,y:c.y,r:c.radius,ex:c.endX,ey:c.endY,er:c.endRadius}),'Wrote authoritative native state');
    return {renderX:output,physicalX:c.x,packetTarget:c.endX};
  ''')
  await check('Display camera and log zoom move without overwriting native camera',r'''
    rp.motion.ultraView=null;rp.motion.frameNow=12000;rp.world.camera();
    const initial={x:rp.motion.ultraView.x,z:rp.motion.ultraView.zoom};
    h.camera.x=12000;h.camera.y=14000;h.camera.zoom=.6;
    for(let t=12010;t<=12200;t+=10){rp.motion.frameNow=t;rp.world.camera();}
    const v=rp.motion.ultraView,scale=r.X_._3473/port.frame.contentWindow.innerWidth;
    assert(h.camera.x===12000&&h.camera.y===14000&&h.camera.zoom===.6,'Mutated native camera');
    assert(Math.abs(r.z_._3852._7847-rp.world.offset-v.x)<1e-6,'Pixi did not use visual camera');
    assert(Math.abs(r.z_._4336-v.zoom*scale)<1e-7,'Pixi did not use log-smoothed zoom');
    assert(v.zoom>0&&v.zoom<.6,'Zoom snapped');return {initial,visual:{x:v.x,y:v.y,z:v.zoom},native:{x:h.camera.x,y:h.camera.y,z:h.camera.zoom}};
  ''')
  await check('Native cursor serializer receives displayed center, not lagging camera mismatch',r'''
    rp.hideMenu();h.player.isStopped=false;h.input.mouse.x=innerWidth/2;h.input.mouse.y=innerHeight/2;
    const calls=[],cursor=h.packets.cursor;h.packets.cursor=(...a)=>calls.push(a);
    const before={x:h.camera.x,y:h.camera.y,z:h.camera.zoom},v=rp.motion.inputCamera();
    try{h.actions.sendMouse();}finally{h.packets.cursor=cursor;}
    assert(calls.length>0,'Native cursor path did not execute');
    assert(calls.some(a=>Math.abs(a[0]-v.x)<1e-5&&Math.abs(a[1]-v.y)<1e-5),'Mouse not aimed through displayed viewport: '+JSON.stringify(calls));
    assert(h.camera.x===before.x&&h.camera.y===before.y&&h.camera.zoom===before.z,'Input failed to restore camera');return {calls,visualCenter:[v.x,v.y]};
  ''')
  await check('Repeated same-time scene reads do not add motion',r'''
    const c=h.world.cells.get(500);rp.motion.frameNow=12300;rp.motion.sample(c);rp.world.camera();
    const before=JSON.stringify(rp.motion.ultraView),x=rp.motion.sample(c).x;
    for(let i=0;i<30;i++){rp.world.camera();assert(rp.motion.sample(c).x===x,'Cell advanced twice');}
    assert(JSON.stringify(rp.motion.ultraView)===before,'Camera advanced twice');return {repetitions:30};
  ''')
  await check('Native wheel increments/limits and ejected-pellet geometry are untouched',r'''
    h.camera.targetZoom=.3;const f=h.settings.zoomSpeed;rp.motion.wheel({deltaY:1});assert(Math.abs(h.camera.targetZoom-.3*f)<1e-9,'Wheel rate changed');
    const c=new h.Cell(9000,7300,7100,20,2);h.world.cells.set(9000,c);rp.world.sync();
    const view=rp.world.cells.get(9000).view,stage=new r.c.W20();r.Bt._6212();r.Bt._7703(view,stage);
    assert(stage.children[0].width===40&&stage.children[0].alpha===1,'Changed pellet size or opacity');return {diameter:40,wheelFactor:f};
  ''')
  await check('Slow cinematic interpolation cannot keep consumed cells alive',r'''
    const c=h.world.cells.get(500),old={removed:c.removed,dt:c.dt};c.removed=true;c.dt=1;
    try{assert(rp.motion.sample(c).u===1,'Extended native lifetime');}finally{Object.assign(c,old);}return {nativeLifetime:true};
  ''')
  await check('Extra-floaty preset does not overwrite the old XPLUS tuning',r'''
    rp.saveSetting('xplus-settle-ms',140);const ms=h.settings.cellAnimation;
    rp.motion.useUltraPreset(800);assert(r.Q.XPLUS_SETTLE_MS._5997()===800,'Preset not applied');
    assert(rp.setting('xplus-ultra-settle-ms',0)===800&&rp.setting('xplus-settle-ms',0)===140,'Preference namespaces mixed');
    assert(h.settings.cellAnimation===ms,'Changed native cell delay');rp.motion.useUltraPreset(420);return {oldXplus:140,ultraIndependent:true};
  ''')
  await check('Senpa and Ryuten restore exact native camera and unchanged linear cells',r'''
    for(const style of ['Senpa','Ryuten']){r.Q.PRESENTATION_STYLE._7531(style);h.camera.x=8123;h.camera.zoom=.3;rp.world.camera();
      assert(rp.motion.ultraView===null,'Stale cinematic history');assert(Math.abs(r.z_._3852._7847-rp.world.offset-h.camera.x)<1e-7,'Native profile changed');}
    const c=h.world.cells.get(500);c.x=c.startX=c.endX=7500;c.y=c.startY=c.endY=8000;rp.motion.records.delete(c);
    r.Q.ELEMENT_ANIMATION_SOFTENING._7531(160);c.update(8500,8000,100,20000);assert(Math.abs(rp.motion.sample(c,20080).x-8000)<1e-7,'Ryuten half-step changed');
    return {nativeProfiles:2,ryutenHalfStep:8000};
  ''')
  await check('Replay/native UI bypass visual filtering and reset its camera cache',r'''
    r.Q.PRESENTATION_STYLE._7531('XPLUS');rp.world.camera();const was=h.network.isReplay;h.network.isReplay=true;
    try{assert(rp.motion.camera()===false&&rp.motion.ultraView===null,'Replay filtered');}finally{h.network.isReplay=was;}
    const mode=port.mode;port.mode='native';try{assert(!rp.motion.camera(),'Native UI filtered');}finally{port.mode=mode;}
    return {bypasses:true};
  ''')
  await check('Bounded traces include both physics/native and visible camera without private payloads',r'''
    rp.motion.useUltraPreset(420);rp.capture.start({seconds:1,maxCells:2});let text='';const download=rp.download;
    for(let i=0;i<5;i++)rp.frame(performance.now()+i*16);
    rp.download=(name,body)=>{text=body;};try{rp.capture.download();}finally{rp.download=download;}
    const data=JSON.parse(text),frames=data.trace.frames;assert(frames.length===5&&frames.every(f=>f.renderCamera),'Missing visible transform');
    assert(!/authToken|skinURL|chat_messages|cookie/.test(text),'Private payload included');return {frames:frames.length,renderAndNative:true};
  ''')
  await page.evaluate('()=>{const p=SENPA_PORT; p.child.motion.reset();p.onFrame=p.child.frame;p.child.showMenu();}')
  await page.wait_for_timeout(450)  # screenshot only; not a readiness assertion
  await page.screenshot(path=str(ROOT/'verification/xplus-ultra-menu.png'))
  await browser.close()
 result={'kind':'OFFLINE_PACKAGED_NATIVE_ENGINE','network':'FIXTURE','gpu':'SUBSTITUTED_SUBMISSION','tests':results,'pageErrors':errors,'artifactSha256':hashlib.sha256((ROOT/'dist/RYUTEN-Senpa.user.js').read_bytes()).hexdigest(),'pass':all(x['pass'] for x in results) and not errors}
 (ROOT/'verification/xplus-ultra-browser.json').write_text(json.dumps(result,indent=2)+'\n')
 return result['pass']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(main()) else 1)
