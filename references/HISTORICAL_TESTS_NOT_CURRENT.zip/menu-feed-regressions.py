"""Feed slider through real native input, packets and Ryuten UI; external services/GPU are fixtures."""
import asyncio, importlib.util, json, pathlib, shutil
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('smoke',ROOT/'tests/browser-smoke.py')
smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)

async def run():
 results=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=chromium_path(),headless=True)
  page=await browser.new_page(viewport={'width':1440,'height':1000})
  async def route(rt):
   if rt.request.url.startswith('https://api.senpa.io/tracker'):
    await rt.fulfill(body=(ROOT/'references/tracker.json').read_text(),content_type='application/json',headers={'Access-Control-Allow-Origin':'*'})
   else:await rt.abort()
  await page.route('**/*',route);await page.set_content('<html><body></body></html>')
  await page.evaluate('('+smoke.HOOK+')()');await page.evaluate((ROOT/'dist/RYUTEN-Senpa.user.js').read_text(encoding='utf8'))
  await page.wait_for_function('SENPA_PORT.ready||SENPA_PORT.error',timeout=30000)
  assert await page.evaluate('SENPA_PORT.ready'),await page.evaluate('SENPA_PORT.error')
  await page.evaluate((ROOT/'tests/browser-fixtures.js').read_text());await page.evaluate('FIXTURE.connect()')
  frame=await(await page.locator('#ryuten-senpa-frame').element_handle()).content_frame()
  async def check(name,code):
   try:
    detail=await page.evaluate('async()=>{const {h,port,rp,r,assert,Writer,world,advance,sent}=FIXTURE;'+code+'}')
    results.append({'case':name,'pass':True,'detail':detail});print('PASS',name,flush=True)
   except Exception as error:
    results.append({'case':name,'pass':False,'error':str(error)});print('FAIL',name,str(error),flush=True)
  await check('Native is the default and feed setting exports without credentials',"""
    assert(r.Q.FEED_INTERVAL_MS._5997()===0&&rp.feedTiming.usingNativeCadence,'Not native by default');
    let data;const original=rp.download;rp.download=(name,text)=>data=JSON.parse(text);rp.exportSettings();rp.download=original;
    assert(data.ryuten.FEED_INTERVAL_MS===0,'Feed setting absent from export');return data.ryuten.FEED_INTERVAL_MS;
  """)
  await frame.locator('[data-senpa-feed]').focus();await page.keyboard.press('Home');
  for _ in range(50): await page.keyboard.press('ArrowRight')
  await check('Actual accessible slider persists 50 ms',"""
    assert(r.Q.FEED_INTERVAL_MS._5997()===50,'Keyboard slider did not change');
    assert(rp.feedTiming.intervalMs===50&&rp.setting('feed-interval-ms')===50,'Controller/persistence mismatch');return rp.feedTiming.intervalMs;
  """)
  await check('Real native macro action sends single eject packets and stops on menu',"""
    world([{id:501,x:7000,y:7000,radius:200,parent:100},{id:502,x:7600,y:7000,radius:150,parent:101}]);advance();rp.hideMenu();
    sent.length=0;h.actions.macroFeed(true);
    assert(sent.some(p=>p[0]===23&&p[1]===0&&p[2]===0),'No single eject request');
    assert(!sent.some(p=>p[0]===23&&p[2]===1&&p[3]===1),'Native auto-feed also enabled');
    rp.showMenu();assert(!rp.feedTiming.running,'Menu left timer running');
    const count=sent.filter(p=>p[0]===23).length;await new Promise(resolve=>setTimeout(resolve,100));
    assert(sent.filter(p=>p[0]===23).length===count,'Feed after menu opened');return count;
  """)
  await check('Native dual tab switching follows selected slot without duplicate stream',"""
    rp.hideMenu();port.setSetting('feedFollowsTab',true);h.player.activeTab=0;sent.length=0;h.actions.macroFeed(true);h.actions.togglePlayer();
    assert(h.player.activeTab===1,'Native tab did not switch');assert(rp.feedTiming.targetSlot===1,'Custom feed not transferred');
    assert(!sent.some(p=>p[0]===23&&p[1]===1&&p[2]===0),'Switch injected an extra pulse');await new Promise(resolve=>setTimeout(resolve,80));assert(sent.some(p=>p[0]===23&&p[1]===1&&p[2]===0),'No scheduled pulse on second native slot');h.actions.macroFeed(false);
    assert(!rp.feedTiming.running,'Release failed');return sent.filter(p=>p[0]===23);
  """)
  await check('Opening chat releases feed before keyboard focus moves into the input',"""
    rp.hideMenu();h.actions.macroFeed(true);assert(rp.feedTiming.running,'No custom feed');rp.toggleChat();
    assert(h.menu.isChatFocused&&!rp.feedTiming.running,'Chat left feed running');rp.toggleChat();return true;
  """)
  await check('Native automatic feed and single-feed remain original protocol',"""
    r.Q.FEED_INTERVAL_MS._7531(0);sent.length=0;h.actions.macroFeed(true);h.actions.macroFeed(false);h.actions.feed();
    const feeds=sent.filter(p=>p[0]===23);assert(feeds.some(p=>p[2]===1&&p[3]===1),'No native macro start');
    assert(feeds.some(p=>p[2]===1&&p[3]===0),'No native macro release');assert(feeds.some(p=>p[2]===0),'No single feed');return feeds;
  """)
  await check('Production frame has no unhandled errors',"""
    const errors=port.logs.filter(x=>x.event==='presentation-error');assert(errors.length===0,JSON.stringify(errors));rp.showMenu();return rp.world.frameCount;
  """)
  await page.screenshot(path=str(ROOT/'verification/menu-feed.png'))
  output={'network':'fixtures','gpu':'substituted submission','cases':results,'pass':all(x['pass'] for x in results)}
  (ROOT/'verification/menu-feed-regressions.json').write_text(json.dumps(output,indent=2),encoding='utf8')
  await browser.close();return output['pass']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(run()) else 1)
