"""Separate, unsubstituted WebGL context probe. Does not certify GPU gameplay."""
import asyncio,json,pathlib,shutil
from playwright.async_api import async_playwright
from browser_path import chromium_path
ROOT=pathlib.Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=chromium_path(),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page()
  result=await page.evaluate('''()=>{const result={};for(const type of ['webgl2','webgl']){const c=document.createElement('canvas'),g=c.getContext(type);result[type]=!!g;if(g){const e=g.getExtension('WEBGL_debug_renderer_info');result[type+'Renderer']=e?g.getParameter(e.UNMASKED_RENDERER_WEBGL):g.getParameter(g.RENDERER);}}return result;}''')
  result['scope']='Unsubstituted headless Chromium capability only; not extension/live gameplay testing'
  (ROOT/'verification/release/graphics-capability.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result));await browser.close()
asyncio.run(main())
