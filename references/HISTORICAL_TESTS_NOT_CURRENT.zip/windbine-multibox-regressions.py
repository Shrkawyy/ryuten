"""Native two-connection/four-tab WindBine regression tests.

The native Senpa engine and WASM are exercised with fixture transport; no live
server, account, CAPTCHA or GPU certification is implied.
"""
import asyncio
import importlib.util
import json
import pathlib
import shutil

from playwright.async_api import async_playwright

from browser_path import chromium_path
ROOT = pathlib.Path(__file__).resolve().parents[1]
CHROME = chromium_path()
spec = importlib.util.spec_from_file_location("smoke", ROOT / "tests" / "browser-smoke.py")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)

PREPARE = r'''()=>{
const port=SENPA_PORT;
port.test.prepareAux=(w,p)=>{
  const done=p.hostReadyResolve;
  p.hostReadyResolve=h=>{done(h);const wait=()=>{if(!h.wasm.create){w.setTimeout(wait,10);return;}
    h.wasm.create=(url,onOpen,onClose,onMessage,onError)=>{const s={url,readyState:0,sent:[],addEventListener(){},send(b){this.sent.push([...new w.Uint8Array(b.buffer||b,b.byteOffset||0,b.byteLength)]);},close(){this.readyState=3;},open(){this.readyState=1;onOpen();},receive(b){onMessage(new w.Uint8Array(b).buffer);},networkClose(){this.readyState=3;onClose();}};w.testSocket=s;return s;};};wait();};
};
window.WBTEST={p:port,h:SENPA_HOST,r:port.child.reference,m:port.multibox};
const T=WBTEST;
T.send=(host,bytes)=>{const realm=host===T.h?window:T.m.aux.frame.contentWindow;host.parser.parse(new realm.Uint8Array(bytes).buffer);};
class Writer{constructor(op){this.b=[op];}u8(n){this.b.push(n&255);return this;}u16(n){return this.u8(n).u8(n>>8);}u32(n){return this.u16(n).u16(n>>>16);}s8(s){this.u8(s.length);for(let i=0;i<s.length;i++)this.u8(s.charCodeAt(i));return this;}s16(s){this.u8(s.length);for(let i=0;i<s.length;i++)this.u16(s.charCodeAt(i));return this;}send(h){T.send(h,this.b);return this;}}
T.W=Writer;
T.assign=(h,cid,pids)=>{const w=new Writer(0).u32(16000).u16(cid).u8(pids.length);for(const pid of pids)w.u16(pid);w.send(h);new Writer(8).send(h);};
T.info=(h,players)=>{const clients=[...new Map(players.map(([pid,cid,nick])=>[cid,nick||('Client '+cid)])),[43,'Enemy']];const w=new Writer(10).u8(clients.length);for(const[id,nick]of clients)w.u16(id).u8(0).s16(nick).s16('team-opaque').u8(255).u8(150).u8(30).u8(0).s16('CLAN');w.u8(0).u8(0).send(h);const q=new Writer(11).u8(players.length+1);for(const[pid,cid]of players)q.u16(pid).u16(cid).u8(250).u8(70).u8(160).s8('').u32(0);q.u16(999).u16(43).u8(80).u8(210).u8(90).s8('').u32(0);q.u8(0).u8(0).send(h);};
T.world=(h,adds=[],updates=[],remove=[],eaten=[])=>{const w=new Writer(20).u16(eaten.length);for(const[a,b]of eaten)w.u32(a).u32(b);w.u16(adds.length);for(const c of adds)w.u32(c.id).u32(c.x??7000).u32(c.y??7000).u16(c.radius??100).u8(c.type??0).u16(c.parent??100).u8(240).u8(90).u8(180);w.u16(updates.length);for(const c of updates)w.u32(c.id).u32(c.x).u32(c.y).u16(c.radius);w.u16(remove.length);for(const id of remove)w.u32(id);w.send(h);};
T.frame=()=>{const now=performance.now();T.h.player.update(now);T.h.camera.update();T.h.world.update(now);T.m.tick(now);T.p.flushActions();T.p.child.frame(now);};
T.assert=(x,msg)=>{if(!x)throw Error(msg);};
T.primarySocket={readyState:1,sent:[],send(x){this.sent.push([...new Uint8Array(x.buffer||x,x.byteOffset||0,x.byteLength)]);},close(){this.readyState=3;}};
T.h.network.ws=T.primarySocket;T.h.network.url='eu1.senpa.io:7112';T.p.selected=T.h.network.url;
T.p.tracker.stop();T.p.tracker.servers=[{id:27,host:T.h.network.url,name:'WindBine',region:'EU',mode:'megasplit2',modeName:'MegaSplitX',players:50,capacity:50}];
T.assign(T.h,41,[100,101]);T.info(T.h,[[100,41,'Pair One'],[101,42,'Pair One B']]);T.world(T.h,[{id:1,parent:100,x:7000,y:7000,radius:180},{id:2,parent:101,x:7200,y:7000,radius:140}]);T.frame();
return {windbine:T.m.isWindBine,assigned:T.h.world.myPlayerIDs.slice(),region:T.m.server()?.region};
}'''


async def main() -> bool:
    results = []
    errors = []
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(executable_path=CHROME, headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
        page = await browser.new_page(viewport={"width": 1440, "height": 1000})
        page.on("pageerror", lambda error: errors.append(str(error)))

        async def route(request):
            if request.request.url.startswith("https://api.senpa.io/tracker"):
                await request.fulfill(status=200, body=(ROOT / "references" / "tracker.json").read_text(), content_type="application/json", headers={"Access-Control-Allow-Origin": "*"})
            else:
                await request.abort()

        await page.route("**/*", route)
        await page.set_content("<!doctype html><html><head></head><body></body></html>")
        await page.evaluate("(" + smoke.HOOK + ")()")
        await page.evaluate((ROOT / "dist" / "RYUTEN-Senpa.user.js").read_text(encoding="utf8"))
        await page.wait_for_function("SENPA_PORT.ready||SENPA_PORT.error", timeout=30000)
        if not await page.evaluate("SENPA_PORT.ready"):
            print("BOOT FAIL", await page.evaluate("SENPA_PORT.error"))
            await browser.close()
            return False

        async def check(name, body):
            try:
                data = await page.evaluate("async()=>{const T=WBTEST,{h,p,r,m,assert}=T;" + body + "}")
                results.append({"name": name, "pass": True, "data": data})
                print("PASS", name, data)
            except Exception as error:
                results.append({"name": name, "pass": False, "error": str(error)})
                print("FAIL", name, str(error)[:1200])

        print("SETUP", await page.evaluate(PREPARE))
        await check("Tracker and controller stay EU WindBine-only", """
          assert(p.tracker.servers.every(s=>s.region==='EU'),'non-EU server leaked into catalogue');
          assert(m.isWindBine&&m.isSupported,'WindBine controller not selected');
          return {servers:p.tracker.servers.length,region:m.server().region,name:m.server().name};
        """)
        await check("Two named pairs expose four logical native tabs", """
          r.Q.WINDBINE_MULTIBOX_ENABLED._7531(true);m.profile(0,{name:'Pair Alpha'});m.profile(1,{name:'Pair Beta'});
          assert(m.multi,'WindBine multibox did not activate');assert(m.tabCount()===4,'wrong logical tab count');assert(!m.aux,'pair 2 started before request');
          return {profiles:m.profiles.map(p=>p.name),tabs:m.tabCount(),mode:m.snapshot().mode};
        """)
        await check("Readonly merge preserves primary native slots before Pair 2 connects", """
          T.frame();const w=p.child.world.model;assert(w.myPlayerIDs.length===2,'primary ID count '+w.myPlayerIDs.length);assert(m.tabCount()===4,'logical tab count was not reserved');assert(w.myPlayerIDs[0]===100&&w.myPlayerIDs[1]===101,'primary IDs were remapped');assert(w.myCells.length===2,'primary cell slot count');assert(w.cells.size===2,'primary cells missing');assert(w.ownerSlots.get(100)===0&&w.ownerSlots.get(101)===1,'primary ownership map wrong');return {ids:w.myPlayerIDs,owners:[w.ownerSlots.get(100),w.ownerSlots.get(101)],cells:w.cells.size};
        """)
        await check("Pair 2 queues, connects natively, positions beside pair 1, then spawns", """
          m.requestPair(1);assert(m.intent?.slot===2,'pair 2 intent missing');const loading=m.loading;assert(loading,'pair 2 engine was not lazy');await loading;assert(m.aux?.host,'pair 2 native host missing');const a=m.aux.host,s=m.aux.frame.contentWindow.testSocket;assert(s&&s.url.includes('eu1.senpa.io:7112'),'wrong pair 2 endpoint');s.open();T.assign(a,44,[200,201]);T.info(a,[[200,44,'Pair Two'],[201,45,'Pair Two B']]);T.frame();const positioned=s.sent.some(b=>b[0]===20);await new Promise(resolve=>setTimeout(resolve,130));T.frame();assert(positioned,'native spectator cursor was not sent');assert(s.sent.some(b=>b[0]===0&&b[1]===0),'pair 2 spawn did not use native slot zero');return {positioned,spawn:s.sent.filter(b=>b[0]===0).map(b=>b.slice(0,2)),status:m.status};
        """)
        await check("Pair 2 acknowledgement adds tabs 3 and 4 without duplicate cells", """
          T.world(m.aux.host,[{id:3,parent:200,x:7100,y:7000,radius:160},{id:4,parent:201,x:7300,y:7000,radius:120}]);T.frame();const w=p.child.world.model;assert(m.active===2&&m.activePair===1,'pair 2 was not activated');assert(w.myPlayerIDs[2]===200&&w.myPlayerIDs[3]===201,'aux IDs were not logicalized');assert(w.cells.size===4,'merged pair cells duplicated or missing');assert(w.ownerSlots.get(200)===2&&w.ownerSlots.get(201)===3,'aux ownership map wrong');return {active:m.active,ids:w.myPlayerIDs,cells:w.cells.size};
        """)
        await check("Input routes to the active native tab inside the selected pair", """
          const s=m.aux.frame.contentWindow.testSocket,before=s.sent.length;h.actions.split();let added=s.sent.slice(before);assert(added.some(b=>b[0]===22&&b[1]===0),'pair 2 player 1 did not receive native slot zero');m.select(3);const next=s.sent.length;h.actions.split();added=s.sent.slice(next);assert(added.some(b=>b[0]===22&&b[1]===1),'pair 2 player 2 did not receive native slot one');m.request('switch');assert(m.active===2,'Tab did not switch inside pair 2');return {slot0:added.length>0,active:m.active,nativeTab:m.aux.host.player.activeTab};
        """)
        await check("Ryuten tab strip and Q pair switching follow the four logical tabs", """
          p.child.updateTabs();const doc=p.frame.contentWindow.document,buttons=[...doc.querySelectorAll('#senpa-tabs button')];assert(buttons.length===4,'tab strip count '+buttons.length);assert(buttons[2].title.startsWith('Pair 2'),'pair title missing');m.request('switch-pair');assert(m.activePair===0&&m.active===0,'pair switch did not preserve the active native tab');return {labels:buttons.map(b=>b.textContent),active:m.active,activePair:m.activePair};
        """)
        await check("FFA is supported separately, with one assigned slot per connection", """
          m.destroyAux();p.tracker.servers=[{id:1,host:h.network.url,name:'Fixture FFA',region:'EU',mode:'ffa',modeName:'Free for all'}];
          m.setFFAEnabled(true);assert(m.isSupported&&!m.multi,'Wrong-width assignment was treated as FFA multibox');
          assert(r.Q.FFA_MULTIBOX_ENABLED,'FFA setting missing');T.assign(h,41,[100]);assert(m.multi&&m.tabCount()===2,'FFA controller did not activate');
          assert(m.nativeSlot(1)===0&&m.sourceIndex(1)===1,'FFA route is not secondary native slot zero');
          m.setFFAEnabled(false);return {supported:true,slots:2,wireSlot:0};
        """)
        result = {"scope": "EU WindBine two-connection/four-tab integration", "network": "Fixture transport", "gpu": "Submission substituted", "cases": results, "pageErrors": errors, "pass": all(item["pass"] for item in results) and not errors}
        (ROOT / "verification" / "windbine-multibox-regressions.json").write_text(json.dumps(result, indent=2), encoding="utf8")
        await browser.close()
        return result["pass"]


if __name__ == "__main__":
    raise SystemExit(0 if asyncio.run(main()) else 1)
